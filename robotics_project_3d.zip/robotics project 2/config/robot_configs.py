"""
Robot Physical Configuration Presets
Contains mass, moment of inertia, wheel radius, track width, friction coefficients, and actuator limits.
"""

from dataclasses import dataclass

@dataclass
class RobotConfig:
    name: str
    mass: float            # Total mass m (kg)
    inertia: float         # Moment of inertia I about z-axis (kg*m^2)
    wheel_radius: float    # Radius r of drive wheels (m)
    track_width: float     # Axle distance b between drive wheels (m)
    wheel_mass: float      # Mass m_w of individual wheel (kg)
    wheel_inertia: float   # Moment of inertia I_w of individual wheel (kg*m^2)
    coulomb_friction: float# Viscous friction coefficient B_v
    viscous_friction: float# Viscous friction coefficient F_v
    max_torque: float      # Maximum motor torque per wheel (N*m)
    max_wheel_speed: float # Maximum angular speed of wheel (rad/s)
    max_linear_velocity: float # Max v (m/s)
    max_angular_velocity: float # Max omega (rad/s)

# Standard Academic & Commercial AMR Configurations

TURTLEBOT3_BURGER = RobotConfig(
    name="TurtleBot3 Burger",
    mass=1.0,
    inertia=0.0025,
    wheel_radius=0.033,
    track_width=0.160,
    wheel_mass=0.05,
    wheel_inertia=0.00003,
    coulomb_friction=0.05,
    viscous_friction=0.02,
    max_torque=1.2,
    max_wheel_speed=35.0,
    max_linear_velocity=1.2,
    max_angular_velocity=3.5
)

TURTLEBOT3_WAFFLE = RobotConfig(
    name="TurtleBot3 Waffle",
    mass=1.8,
    inertia=0.0085,
    wheel_radius=0.033,
    track_width=0.287,
    wheel_mass=0.08,
    wheel_inertia=0.00005,
    coulomb_friction=0.08,
    viscous_friction=0.03,
    max_torque=1.8,
    max_wheel_speed=40.0,
    max_linear_velocity=1.2,
    max_angular_velocity=3.0
)

PIONEER_3DX = RobotConfig(
    name="Pioneer 3-DX",
    mass=9.0,
    inertia=0.147,
    wheel_radius=0.096,
    track_width=0.330,
    wheel_mass=0.35,
    wheel_inertia=0.0016,
    coulomb_friction=0.15,
    viscous_friction=0.05,
    max_torque=4.5,
    max_wheel_speed=25.0,
    max_linear_velocity=1.5,
    max_angular_velocity=3.5
)

CONFIGS = {
    "burger": TURTLEBOT3_BURGER,
    "waffle": TURTLEBOT3_WAFFLE,
    "pioneer": PIONEER_3DX
}
