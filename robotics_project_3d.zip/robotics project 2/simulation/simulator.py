"""
Physics Simulation Engine & Dynamic Environment Framework
Integrates kinematic + dynamic robot differential drive physics, moving obstacles,
Lidar raycasting, and performance metrics logging.
"""

import numpy as np
import random
from config.robot_configs import RobotConfig, CONFIGS
from robot_model.kinematics import DifferentialDriveKinematics
from robot_model.dynamics import DifferentialDriveDynamics
from controllers.lyapunov_kinematic import LyapunovKinematicController
from controllers.computed_torque import ComputedTorqueController
from controllers.sliding_mode import SlidingModeController
from controllers.adaptive_fuzzy import AdaptiveFuzzyTuner
from planners.global_planners import AStarPlanner, RRTStarPlanner, GeneticPlanner
from planners.local_planners import ArtificialPotentialField, DynamicWindowApproach
from planners.intelligent_adaptation import IntelligentAdaptationLayer

class DynamicObstacle:
    def __init__(self, pos: tuple[float, float], radius: float = 0.3, velocity: tuple[float, float] = (0.2, 0.0), mode: str = "pingpong", bounds: tuple[float, float] = (1.0, 9.0)):
        self.pos = np.array(pos, dtype=float)
        self.radius = radius
        self.vel = np.array(velocity, dtype=float)
        self.mode = mode
        self.bounds = bounds
        self.start_pos = np.array(pos, dtype=float)

    @staticmethod
    def _blocked(x, y, radius, grid, res):
        """True if a circle at (x, y) overlaps an occupied grid cell."""
        rows, cols = grid.shape
        c0, c1 = int(np.floor((x - radius) / res + 0.5)), int(np.ceil((x + radius) / res - 0.5))
        r0, r1 = int(np.floor((y - radius) / res + 0.5)), int(np.ceil((y + radius) / res - 0.5))
        for r in range(r0, r1 + 1):
            for c in range(c0, c1 + 1):
                if r < 0 or c < 0 or r >= rows or c >= cols or grid[r, c] == 1:
                    # exact circle-vs-cell test (cell centre at c*res, r*res)
                    dx = max(abs(x - c * res) - res / 2, 0.0)
                    dy = max(abs(y - r * res) - res / 2, 0.0)
                    if dx * dx + dy * dy < radius * radius:
                        return True
        return False

    def update(self, dt: float, grid=None, resolution: float = 0.1):
        if self.mode == "pingpong":
            for ax in (0, 1):                       # move axis by axis so it slides/bounces off walls
                new = self.pos.copy()
                new[ax] += self.vel[ax] * dt
                out = new[ax] < self.bounds[0] or new[ax] > self.bounds[1]
                hit = grid is not None and self._blocked(new[0], new[1], self.radius, grid, resolution)
                if out or hit:
                    self.vel[ax] *= -1.0            # bounce, stay in free space
                else:
                    self.pos = new
        elif self.mode == "circular":
            t = np.arctan2(self.pos[1] - self.start_pos[1], self.pos[0] - self.start_pos[0]) + 0.5 * dt
            r = 1.0
            self.pos[0] = self.start_pos[0] + r * np.cos(t)
            self.pos[1] = self.start_pos[1] + r * np.sin(t)
            self.vel[0] = -r * np.sin(t) * 0.5
            self.vel[1] = r * np.cos(t) * 0.5


class LidarSensor:
    def __init__(self, num_beams: int = 36, max_range: float = 5.0):
        self.num_beams = num_beams
        self.max_range = max_range
        self.angles = np.linspace(-np.pi, np.pi, num_beams, endpoint=False)

    def scan(self, robot_pose: np.ndarray, grid: np.ndarray, resolution: float, dynamic_obs: list[DynamicObstacle]) -> np.ndarray:
        rx, ry, rtheta = robot_pose[0], robot_pose[1], robot_pose[2]
        ranges = np.full(self.num_beams, self.max_range)
        rows, cols = grid.shape

        for i, angle in enumerate(self.angles):
            beam_angle = rtheta + angle
            cos_a = np.cos(beam_angle)
            sin_a = np.sin(beam_angle)

            # Raycast step
            for r_dist in np.arange(0.05, self.max_range, 0.08):
                px = rx + r_dist * cos_a
                py = ry + r_dist * sin_a

                # Grid map bounds check
                grid_r = int(round(py / resolution))
                grid_c = int(round(px / resolution))

                if 0 <= grid_r < rows and 0 <= grid_c < cols:
                    if grid[grid_r, grid_c] == 1:
                        ranges[i] = r_dist
                        break
                else: # Out of map boundary
                    ranges[i] = r_dist
                    break

                # Dynamic obstacles check
                hit_dynamic = False
                for obs in dynamic_obs:
                    if np.hypot(px - obs.pos[0], py - obs.pos[1]) <= obs.radius:
                        ranges[i] = r_dist
                        hit_dynamic = True
                        break
                if hit_dynamic:
                    break

        return ranges


class SimulationEngine:
    def __init__(
        self,
        config_name: str = "burger",
        map_size: tuple[int, int] = (10, 10),
        resolution: float = 0.1
    ):
        self.config = CONFIGS.get(config_name, CONFIGS["burger"])
        self.resolution = resolution
        self.rows = int(map_size[1] / resolution)
        self.cols = int(map_size[0] / resolution)
        self.grid = np.zeros((self.rows, self.cols), dtype=int)

        # Initialize Physics & Dynamics
        self.kinematics = DifferentialDriveKinematics(self.config)
        self.dynamics = DifferentialDriveDynamics(self.config)

        # Controllers
        self.kinematic_ctrl = LyapunovKinematicController()
        self.dynamic_ctc = ComputedTorqueController(self.dynamics)
        self.dynamic_smc = SlidingModeController(self.dynamics)
        self.fuzzy_tuner = AdaptiveFuzzyTuner()

        # Adaptation & Lidar
        self.adaptation_layer = IntelligentAdaptationLayer()
        self.lidar = LidarSensor()

        # State Variables
        self.pose = np.array([1.0, 1.0, 0.0]) # [x, y, theta]
        self.v_vec = np.zeros(2)             # [v, omega]
        self.wheel_torques = np.zeros(2)     # [tau_l, tau_r]
        self.goal = np.array([9.0, 9.0])
        self.dynamic_obstacles = []
        self.global_path = []
        self.current_waypoint_index = 1
        # Smooth velocity command sent to the dynamic controller.
        self.commanded_v = 0.0
        self.commanded_omega = 0.0
        self._prev_vel_err = 0.0
        self.trajectory_history = []
        self.telemetry = {
            "time": [], "x": [], "y": [], "v": [], "omega": [],
            "tau_l": [], "tau_r": [], "e_x": [], "e_y": [], "energy": []
        }
        self.sim_time = 0.0
        # Accumulated absolute mechanical work at the two drive wheels (J).
        # Power = |tau_l * omega_l + tau_r * omega_r|.
        self.total_energy = 0.0
        self.is_done = False
        self.collision_occurred = False
        self.scenario_seed = None
        self.planner_used = "AStar"
        self.path_is_safe = True

    def setup_default_map(self, scenario_seed=None, start=(1.0, 1.0), goal=(9.0, 9.0)):
        """Build the default map and generate a fresh dynamic-obstacle scenario.

        If scenario_seed is supplied, the scenario is reproducible (used by the
        benchmark). If omitted, each reset gets a new randomized scenario.
        """
        # Outer boundary walls
        self.grid[0, :] = 1
        self.grid[-1, :] = 1
        self.grid[:, 0] = 1
        self.grid[:, -1] = 1

        # Central pillar obstacles
        self.grid[30:70, 35:45] = 1
        self.grid[15:25, 65:85] = 1
        self.grid[75:85, 15:35] = 1

        # Dynamic obstacles: randomize each new simulation/reset so the robot
        # is tested against different moving-obstacle scenarios. A fixed seed
        # can be supplied by the benchmark for reproducible trials.
        self.scenario_seed = scenario_seed
        rng = random.Random(scenario_seed) if scenario_seed is not None else random.SystemRandom()
        candidates = [
            (2.0, 2.0), (2.0, 5.0), (2.0, 8.0), (3.0, 4.0), (3.0, 7.5),
            (5.0, 2.0), (5.0, 8.0), (7.0, 2.0), (7.0, 5.0), (8.0, 5.0),
            (8.0, 8.0), (4.5, 7.5), (7.5, 3.0)
        ]
        # Keep dynamic obstacles away from the default start/goal and static pillars.
        safe_candidates = []
        for c in candidates:
            x, y = c
            if np.hypot(x - start[0], y - start[1]) < 1.3 or np.hypot(x - goal[0], y - goal[1]) < 1.3:
                continue
            # Static pillar regions in metres.
            if (3.5 <= x <= 4.5 and 3.0 <= y <= 7.0) or (6.5 <= x <= 8.5 and 1.5 <= y <= 2.5) or (1.5 <= x <= 3.5 and 7.5 <= y <= 8.5):
                continue
            safe_candidates.append(c)
        rng.shuffle(safe_candidates)
        chosen = safe_candidates[:3]
        if len(chosen) < 3:
            # Wider pool so user-selected start/goal points still get 3 safe obstacles.
            pool = []
            for gx in np.arange(1.5, 8.6, 1.0):
                for gy in np.arange(1.5, 8.6, 1.0):
                    if np.hypot(gx - start[0], gy - start[1]) < 1.3 or np.hypot(gx - goal[0], gy - goal[1]) < 1.3:
                        continue
                    if (3.2 <= gx <= 4.8 and 2.7 <= gy <= 7.3) or (6.2 <= gx <= 8.8 and 1.2 <= gy <= 2.8) or (1.2 <= gx <= 3.8 and 7.2 <= gy <= 8.8):
                        continue
                    pool.append((float(gx), float(gy)))
            rng.shuffle(pool)
            chosen = (chosen + pool)[:3]

        bounds = [(2.0, 8.0), (2.0, 8.0), (1.5, 8.5)]
        obstacles = []
        for i, pos in enumerate(chosen):
            angle = rng.uniform(0.0, 2.0 * np.pi)
            speed = rng.uniform(0.18, 0.38)
            velocity = (speed * np.cos(angle), speed * np.sin(angle))
            # Ensure each obstacle has meaningful motion in both axes.
            if abs(velocity[0]) < 0.08 and abs(velocity[1]) < 0.08:
                velocity = (speed, 0.0)
            obstacles.append(DynamicObstacle(pos=pos, radius=0.3, velocity=velocity, mode="pingpong", bounds=bounds[i]))
        self.dynamic_obstacles = obstacles

    def _nearby_static_points(self, reach: float = 0.8, d_0: float = 0.45) -> list[dict]:
        """Closest occupied grid cell in each of 16 sectors around the robot."""
        res = self.resolution
        cr, cc = int(round(self.pose[1] / res)), int(round(self.pose[0] / res))
        n = int(reach / res)
        best = {}
        for r in range(cr - n, cr + n + 1):
            for c in range(cc - n, cc + n + 1):
                inside = 0 <= r < self.rows and 0 <= c < self.cols
                if inside and self.grid[r, c] != 1:
                    continue
                px, py = c * res, r * res
                dx, dy = px - self.pose[0], py - self.pose[1]
                d = np.hypot(dx, dy)
                if d > reach:
                    continue
                k = int(((np.arctan2(dy, dx) + np.pi) / (2 * np.pi)) * 16) % 16
                if k not in best or d < best[k][0]:
                    best[k] = (d, px, py)
        return [{"pos": [px, py], "radius": 0.0, "vel": [0.0, 0.0], "d_0": d_0}
                for _, px, py in best.values()]

    def validate_point(self, pt, label: str = "Point"):
        """Return an error string if pt is not a usable start/goal, else None."""
        x, y = float(pt[0]), float(pt[1])
        size = self.cols * self.resolution
        if not (0.3 <= x <= size - 0.3 and 0.3 <= y <= self.rows * self.resolution - 0.3):
            return f"{label} must be inside the map (keep 0.3 m from the border)."
        inflated = AStarPlanner(self.grid, self.resolution, self.config.track_width / 2.0 + 0.10).grid
        r, c = int(round(y / self.resolution)), int(round(x / self.resolution))
        if inflated[r, c] == 1:
            return f"{label} is inside or too close to an obstacle/wall."
        for o in self.dynamic_obstacles:
            if np.hypot(x - o.pos[0], y - o.pos[1]) < o.radius + self.config.track_width / 2.0 + 0.3:
                return f"{label} is too close to a moving obstacle."
        return None

    def set_start_and_goal(self, start: tuple[float, float], goal: tuple[float, float]):
        self.pose = np.array([start[0], start[1], 0.0])
        self.goal = np.array([goal[0], goal[1]])
        self.sim_time = 0.0
        self.total_energy = 0.0
        self.trajectory_history = [(self.pose[0], self.pose[1])]
        self.current_waypoint_index = 1
        self.commanded_v = 0.0
        self.commanded_omega = 0.0
        self._prev_vel_err = 0.0
        self.dynamic_ctc.reset()
        self.dynamic_smc.reset()
        self.telemetry = {k: [] for k in self.telemetry.keys()}
        self.is_done = False
        self.collision_occurred = False

    def plan_global_path(self, planner_type: str = "AStar") -> list[tuple[float, float]]:
        """Plan a collision-free static path, with A* as the guaranteed fallback."""
        start_pt = (float(self.pose[0]), float(self.pose[1]))
        goal_pt = (float(self.goal[0]), float(self.goal[1]))
        safe_radius = self.config.track_width / 2.0 + 0.10
        astar = AStarPlanner(self.grid, self.resolution, safe_radius)

        try:
            if planner_type == "RRTStar":
                planner = RRTStarPlanner(self.grid, self.resolution, safe_radius, seed=self.scenario_seed)
            elif planner_type == "Genetic":
                planner = GeneticPlanner(self.grid, self.resolution, safe_radius, seed=self.scenario_seed)
            else:
                planner = astar
            candidate = planner.plan(start_pt, goal_pt)
            self.planner_used = planner_type if not getattr(planner, "used_fallback", False) else "AStar (fallback from %s)" % planner_type
        except Exception:
            candidate = []
            self.planner_used = "AStar (fallback from %s)" % planner_type

        # Never expose a broken/empty path to the controller.
        if not candidate or len(candidate) < 2:
            candidate = astar.plan(start_pt, goal_pt)

        # Sampling-based planners stop within a tolerance of the goal; make sure the
        # path ends exactly at the goal so the robot's goal check (0.3 m) can fire.
        candidate = [tuple(map(float, q)) for q in candidate]
        if np.hypot(candidate[-1][0] - goal_pt[0], candidate[-1][1] - goal_pt[1]) > 1e-6:
            candidate.append(goal_pt)

        # Sampling-based/GA planners can occasionally return an unsafe shortcut.
        # Validate it and fall back to deterministic A* when needed.
        safe = True
        for a, b in zip(candidate[:-1], candidate[1:]):
            if not astar.is_line_collision_free(a, b):
                safe = False
                break
        if not safe:
            candidate = astar.plan(start_pt, goal_pt)

        self.path_is_safe = all(astar.is_line_collision_free(a, b) for a, b in zip(candidate[:-1], candidate[1:]))
        self.global_path = [(float(x), float(y)) for x, y in candidate]
        self.current_waypoint_index = 1 if len(self.global_path) > 1 else 0
        return self.global_path

    def step(self, dt: float = 0.05, controller_mode: str = "CTC", planner_mode: str = "ANFIS_APF", speed_regulator: float = 0.5) -> dict:
        if self.is_done:
            return {
                "pose": self.pose.tolist(),
                "v_vec": self.v_vec.tolist(),
                "torques": np.asarray(self.wheel_torques).tolist(),
                "sim_time": self.sim_time,
                "dist_to_goal": float(np.hypot(self.pose[0] - self.goal[0], self.pose[1] - self.goal[1])),
                "done": True,
                "collision": self.collision_occurred,
                "adapted_params": {},
            }

        # Update dynamic obstacles
        obs_dicts = []
        for obs in self.dynamic_obstacles:
            obs.update(dt, self.grid, self.resolution)
            obs_dicts.append({"pos": obs.pos.tolist(), "radius": obs.radius, "vel": obs.vel.tolist()})

        # Static walls/pillars as short-range repulsive points so reactive
        # avoidance of moving obstacles can never push the robot into them.
        static_pts = self._nearby_static_points()
        obs_dicts_all = obs_dicts + static_pts

        # Feature extraction for intelligent adaptation
        env_features = self.adaptation_layer.extract_environment_features(self.pose, obs_dicts, self.goal)
        speed_regulator = float(np.clip(speed_regulator, 0.05, min(self.config.max_linear_velocity, 0.8)))
        # Conservative safety profile for the combination that is most sensitive
        # to rapid command changes. This still executes SMC, but prevents the
        # local DWA command from driving the plant into a static obstacle.
        if planner_mode == "DWA" and controller_mode == "SMC":
            speed_regulator = min(speed_regulator, 0.40)
        adapted_params = self.adaptation_layer.adapt_parameters(env_features, base_v_max=speed_regulator)

        # Select a monotonic look-ahead waypoint shared by every local planner.
        target_point = self.goal.copy()
        if self.global_path and len(self.global_path) > 1:
            self.current_waypoint_index = min(self.current_waypoint_index, len(self.global_path) - 1)
            while (
                self.current_waypoint_index < len(self.global_path) - 1
                and np.hypot(
                    self.global_path[self.current_waypoint_index][0] - self.pose[0],
                    self.global_path[self.current_waypoint_index][1] - self.pose[1]
                ) < 0.45
            ):
                self.current_waypoint_index += 1
            target_point = np.asarray(self.global_path[self.current_waypoint_index], dtype=float)

        # Local Path & Velocity Command Generation. Unrecognized modes safely
        # fall back to APF so configuration changes do not crash the loop.
        if planner_mode == "DWA":
            try:
                dwa = DynamicWindowApproach(
                    robot_radius=self.config.track_width / 2.0 + 0.05, dt=dt
                )
                # DWA follows the global look-ahead point, not the distant final goal.
                # This makes it compatible with A*/RRT*/GA paths and obstacle corridors.
                inflated = AStarPlanner(
                    self.grid, self.resolution, self.config.track_width / 2.0 + 0.10
                ).grid
                v_target, omega_target = dwa.plan(
                    self.pose, self.v_vec[0], self.v_vec[1], target_point, obs_dicts,
                    max_v=min(adapted_params["v_max"], 0.5), max_w=min(self.config.max_angular_velocity, 1.5),
                    static_grid=inflated, resolution=self.resolution
                )
            except Exception:
                v_target, omega_target = 0.0, 0.0

            # Validate DWA's command with a short forward check. If it is too
            # conservative or points away from the path, use APF as a safe local fallback.
            goal_dist = np.hypot(target_point[0] - self.pose[0], target_point[1] - self.pose[1])
            target_bearing = np.arctan2(target_point[1] - self.pose[1], target_point[0] - self.pose[0])
            bearing_error = abs((target_bearing - self.pose[2] + np.pi) % (2 * np.pi) - np.pi)
            if v_target <= 1e-4 and goal_dist > 0.5 or (bearing_error > 1.6 and v_target > 0.15):
                planner_mode = "APF"

        if planner_mode != "DWA": # APF or ANFIS_APF
            apf = ArtificialPotentialField(
                k_att=adapted_params["k_att"],
                k_rep=adapted_params["k_rep"],
                d_0=adapted_params["d_0"],
                robot_radius=self.config.track_width/2.0 + 0.05
            )
            v_target, omega_target = apf.compute_heading_and_speed(
                self.pose, target_point, obs_dicts_all, max_v=min(adapted_params["v_max"], 0.5), max_omega=1.2
            )

        # Kinematic Layer: Convert desired target into kinematic control
        # The local planner already computes a body-frame velocity command.
        # Track that command directly; applying a distant waypoint pose
        # controller on top of it can introduce an unrelated heading demand.
        dist_to_goal_now = np.hypot(
            self.pose[0] - self.goal[0], self.pose[1] - self.goal[1]
        )
        v_c = min(float(v_target), 0.8 * float(dist_to_goal_now))
        v_c = float(np.clip(v_c, 0.0, min(adapted_params["v_max"], 0.5)))
        omega_c = float(np.clip(omega_target, -1.2, 1.2))

        # Rate-limit the command before sending it to the torque controller.
        # This prevents abrupt wheel-torque reversals when APF changes direction.
        max_dv = 0.8 * dt
        max_dw = 2.0 * dt
        self.commanded_v += float(np.clip(v_c - self.commanded_v, -max_dv, max_dv))
        self.commanded_omega += float(np.clip(omega_c - self.commanded_omega, -max_dw, max_dw))
        target_v_vec = np.array([self.commanded_v, self.commanded_omega])
        e_vec = np.array([
            self.goal[0] - self.pose[0],
            self.goal[1] - self.pose[1],
            0.0
        ])

        # Dynamic Layer: Calculate wheel torques compensating for mass/friction
        try:
            if controller_mode == "SMC":
                tau = self.dynamic_smc.compute_control(self.v_vec, target_v_vec, dt)
            elif controller_mode == "Adaptive_CTC":
                # Fuzzy tuner expects the velocity-tracking error and its rate
                # (not the distance to goal, which kept the gain saturated at max
                # and made the angular loop oscillate).
                vel_err = float(np.linalg.norm(target_v_vec - self.v_vec))
                vel_err_dot = abs(vel_err - self._prev_vel_err) / dt if dt > 0 else 0.0
                self._prev_vel_err = vel_err
                alpha = self.fuzzy_tuner.compute_adaptation_factor(vel_err, vel_err_dot)
                # Boost gain under mass uncertainty.
                self.dynamic_ctc.K_p = 15.0 * alpha
                tau = self.dynamic_ctc.compute_control(self.v_vec, target_v_vec, dt)
            else: # Standard CTC, and safe fallback for unknown values.
                tau = self.dynamic_ctc.compute_control(self.v_vec, target_v_vec, dt)
        except Exception:
            # Keep the simulation alive if a future controller implementation changes.
            tau = self.dynamic_ctc.compute_control(self.v_vec, target_v_vec, dt)

        self.wheel_torques = tau

        # Physics Step: Integrate accelerations (v_dot) and update pose
        v_dot = self.dynamics.forward_dynamics(self.v_vec, tau)
        self.v_vec += v_dot * dt
        # Clamp velocity to max limits defined by speed regulator
        max_allowed_v = min(speed_regulator, self.config.max_linear_velocity, 0.5)
        self.v_vec[0] = float(np.clip(self.v_vec[0], 0.0, max_allowed_v))
        self.v_vec[1] = float(np.clip(self.v_vec[1], -self.config.max_angular_velocity, self.config.max_angular_velocity))

        self.pose = self.kinematics.rk4_step(self.pose, self.v_vec[0], self.v_vec[1], dt)

        # Logging & Telemetry
        # Torque-energy metric: integrate the magnitude of mechanical power
        # delivered at the drive wheels. This has units of joules and is
        # physically meaningful for comparing controller effort.
        wheel_omega_l = (self.v_vec[0] - 0.5 * self.config.track_width * self.v_vec[1]) / self.config.wheel_radius
        wheel_omega_r = (self.v_vec[0] + 0.5 * self.config.track_width * self.v_vec[1]) / self.config.wheel_radius
        mechanical_power = abs(float(tau[0]) * wheel_omega_l + float(tau[1]) * wheel_omega_r)
        step_energy = mechanical_power * dt
        self.total_energy += float(step_energy)
        self.sim_time += dt
        self.trajectory_history.append((float(self.pose[0]), float(self.pose[1])))

        self.telemetry["time"].append(self.sim_time)
        self.telemetry["x"].append(float(self.pose[0]))
        self.telemetry["y"].append(float(self.pose[1]))
        self.telemetry["v"].append(float(self.v_vec[0]))
        self.telemetry["omega"].append(float(self.v_vec[1]))
        self.telemetry["tau_l"].append(float(tau[0]))
        self.telemetry["tau_r"].append(float(tau[1]))
        self.telemetry["e_x"].append(float(e_vec[0]))
        self.telemetry["e_y"].append(float(e_vec[1]))
        self.telemetry["energy"].append(float(self.total_energy))

        # Check collision with static or dynamic obstacles
        r_grid, c_grid = int(round(self.pose[1] / self.resolution)), int(round(self.pose[0] / self.resolution))
        if 0 <= r_grid < self.rows and 0 <= c_grid < self.cols:
            if self.grid[r_grid, c_grid] == 1:
                self.collision_occurred = True
                self.is_done = True

        for obs in self.dynamic_obstacles:
            if np.hypot(self.pose[0] - obs.pos[0], self.pose[1] - obs.pos[1]) <= (obs.radius + self.config.track_width / 2.0):
                self.collision_occurred = True
                self.is_done = True

        # Goal check
        dist_to_goal = np.hypot(self.pose[0] - self.goal[0], self.pose[1] - self.goal[1])
        if dist_to_goal < 0.3:
            self.v_vec[:] = 0.0
            self.commanded_v = 0.0
            self.commanded_omega = 0.0
            self.is_done = True

        return {
            "pose": self.pose.tolist(),
            "v_vec": self.v_vec.tolist(),
            "torques": tau.tolist(),
            "sim_time": self.sim_time,
            "dist_to_goal": dist_to_goal,
            "done": self.is_done,
            "collision": self.collision_occurred,
            "adapted_params": adapted_params
        }
