"""
Fair 20-trial benchmark for the AMR navigation project.

All pipeline strategies are evaluated on the exact same randomized dynamic
obstacle scenarios. The benchmark uses controlled, moderate obstacle motion
so that scenarios remain physically meaningful without placing an obstacle
directly on the start/goal corridor.
"""

import time
import random
import numpy as np
from simulation.simulator import SimulationEngine, DynamicObstacle


class BenchmarkSuite:
    def __init__(self, num_trials: int = 20, max_sim_time: float = 60.0):
        self.num_trials = int(num_trials)
        self.max_sim_time = float(max_sim_time)

    def _make_scenario(self, seed: int):
        """Create one reproducible moderate dynamic-obstacle scenario."""
        rng = random.Random(seed)
        # Three moving obstacles are kept in side/corner regions. Their
        # positions are fixed for a trial and their directions/speeds vary
        # with the seed. Every pipeline receives an identical copy.
        base_positions = [(2.0, 8.0), (8.0, 2.0), (8.0, 7.0)]
        obstacles = []
        for pos in base_positions:
            angle = rng.uniform(0.0, 2.0 * np.pi)
            speed = rng.uniform(0.10, 0.18)
            velocity = (speed * np.cos(angle), speed * np.sin(angle))
            obstacles.append(
                DynamicObstacle(
                    pos=pos, radius=0.22, velocity=velocity,
                    mode="pingpong", bounds=(1.8, 8.2)
                )
            )
        return obstacles

    @staticmethod
    def _clone_obstacles(obstacles):
        return [
            DynamicObstacle(
                pos=tuple(obs.pos), radius=obs.radius,
                velocity=tuple(obs.vel), mode=obs.mode, bounds=obs.bounds
            )
            for obs in obstacles
        ]

    def run_benchmarks(self) -> dict:
        pipelines = [
            {"name": "Classical Baseline", "planner": "AStar", "local": "APF", "controller": "CTC"},
            {"name": "Heuristic Baseline", "planner": "RRTStar", "local": "APF", "controller": "CTC"},
            {"name": "Intelligent Adaptive (Proposed)", "planner": "AStar", "local": "ANFIS_APF", "controller": "Adaptive_CTC"}
        ]

        scenario_seeds = [5000 + trial for trial in range(self.num_trials)]
        scenarios = {seed: self._make_scenario(seed) for seed in scenario_seeds}
        results = {}

        for pipe in pipelines:
            metrics = {
                "success_rate": 0.0, "avg_path_length": [],
                "avg_smoothness": [], "avg_sim_time": [],
                "avg_comp_time_ms": [], "avg_energy": []
            }
            successes = 0

            for trial, seed in enumerate(scenario_seeds):
                # Identical environment; deterministic planner randomness.
                random.seed(seed)
                np.random.seed(seed)
                sim = SimulationEngine(config_name="burger")
                sim.setup_default_map(scenario_seed=seed)
                sim.set_start_and_goal((1.0, 1.0), (9.0, 9.0))
                sim.dynamic_obstacles = self._clone_obstacles(scenarios[seed])
                sim.plan_global_path(pipe["planner"])

                comp_times = []
                while not sim.is_done and sim.sim_time < self.max_sim_time:
                    t0 = time.perf_counter()
                    sim.step(dt=0.05, controller_mode=pipe["controller"], planner_mode=pipe["local"])
                    comp_times.append((time.perf_counter() - t0) * 1000.0)

                if sim.is_done and not sim.collision_occurred:
                    successes += 1
                    path = np.array(sim.trajectory_history)
                    if len(path) > 1:
                        metrics["avg_path_length"].append(
                            np.sum(np.hypot(np.diff(path[:, 0]), np.diff(path[:, 1])))
                        )
                    omegas = np.array(sim.telemetry["omega"])
                    if len(omegas) > 1:
                        metrics["avg_smoothness"].append(np.sum(np.diff(omegas) ** 2) * 0.05)
                    metrics["avg_sim_time"].append(sim.sim_time)
                    metrics["avg_energy"].append(sim.total_energy)

                metrics["avg_comp_time_ms"].append(np.mean(comp_times) if comp_times else 0.0)

            results[pipe["name"]] = {
                "success_rate_percent": (successes / self.num_trials) * 100.0,
                "mean_path_length_m": float(np.mean(metrics["avg_path_length"])) if metrics["avg_path_length"] else 0.0,
                "mean_smoothness": float(np.mean(metrics["avg_smoothness"])) if metrics["avg_smoothness"] else 0.0,
                "mean_convergence_time_s": float(np.mean(metrics["avg_sim_time"])) if metrics["avg_sim_time"] else 0.0,
                "mean_comp_time_per_step_ms": float(np.mean(metrics["avg_comp_time_ms"])),
                "mean_torque_energy_J": float(np.mean(metrics["avg_energy"])) if metrics["avg_energy"] else 0.0
            }

        return results


if __name__ == "__main__":
    suite = BenchmarkSuite(num_trials=20)
    res = suite.run_benchmarks()
    print("--- BENCHMARK RESULTS ---")
    for k, v in res.items():
        print(f"\n[{k}]")
        for metric, val in v.items():
            print(f"  {metric}: {val:.4f}")
