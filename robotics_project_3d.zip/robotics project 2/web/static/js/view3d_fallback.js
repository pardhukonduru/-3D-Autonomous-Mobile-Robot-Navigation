/*
 * view3d.js - self-contained real-time 3D view of the simulation.
 * No external libraries: a small perspective engine on a 2D canvas
 * (back-face culling, flat shading, painter's-algorithm depth sorting).
 *
 * World frame: x right, y forward, z up (metres). Same x/y as the 2D map.
 * Public API (window.View3D): init, setGrid, setRobot, render, redraw,
 *                             setMode, onGroundClick
 */
(function () {
    "use strict";

    // ---------- small vector helpers ----------
    const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
    const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
    const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
    const norm = a => { const l = Math.hypot(a[0], a[1], a[2]) || 1; return [a[0] / l, a[1] / l, a[2] / l]; };
    const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
    const wrapPi = a => { while (a > Math.PI) a -= 2 * Math.PI; while (a < -Math.PI) a += 2 * Math.PI; return a; };
    const LIGHT = norm([-0.45, -0.55, 0.85]);

    const MAP = 10.0;
    const ROBOT_VIS_SCALE = 3.0;      // robot models are enlarged so they are visible on a 10 m map

    let cv = null, g = null, W = 600, H = 600, FPX = 640;
    let rects = [];                   // static obstacles merged into boxes
    let robotGeo = { track_width: 0.16, wheel_radius: 0.033 };
    let last = null, lastStart = [1, 1];
    let C = null;                     // per-frame camera {pos, f, right, up}
    const cam = { az: -Math.PI / 2, el: 0.62, dist: 15.5, target: [5, 5, 0], mode: "orbit" };
    const api = { onGroundClick: null };

    // ---------- static map -> merged boxes ----------
    function buildRects(grid) {
        const rows = grid.length, cols = grid[0].length, res = MAP / cols;
        const seen = grid.map(r => r.map(() => false));
        const out = [];
        for (let r = 0; r < rows; r++) {
            for (let c = 0; c < cols; c++) {
                if (grid[r][c] !== 1 || seen[r][c]) continue;
                let w = 1;
                while (c + w < cols && grid[r][c + w] === 1 && !seen[r][c + w]) w++;
                let h = 1, ok = true;
                while (r + h < rows && ok) {
                    for (let k = 0; k < w; k++) if (grid[r + h][c + k] !== 1 || seen[r + h][c + k]) { ok = false; break; }
                    if (ok) h++;
                }
                for (let i = 0; i < h; i++) for (let k = 0; k < w; k++) seen[r + i][c + k] = true;
                const x0 = (c - 0.5) * res, x1 = (c + w - 0.5) * res;
                const y0 = (r - 0.5) * res, y1 = (r + h - 0.5) * res;
                const border = x0 <= 0.06 || y0 <= 0.06 || x1 >= MAP - 0.15 || y1 >= MAP - 0.15;
                out.push({ x0, y0, x1, y1, border });
            }
        }
        return out;
    }

    // ---------- camera ----------
    function updateCamera(data) {
        if (cam.mode === "top") {
            cam.az = -Math.PI / 2; cam.el = 1.50; cam.dist = 15.5; cam.target = [5, 5, 0];
        } else if (cam.mode === "chase" && data && data.pose) {
            const th = data.pose[2];
            cam.az += wrapPi(th + Math.PI - cam.az) * 0.18;
            cam.el = 0.42; cam.dist = 4.2;
            cam.target = [data.pose[0], data.pose[1], 0.2];
        } else if (cam.mode === "orbit") {
            cam.target = [5, 5, 0];
        }
        const ce = Math.cos(cam.el), se = Math.sin(cam.el);
        const t = cam.target;
        const pos = [t[0] + cam.dist * ce * Math.cos(cam.az), t[1] + cam.dist * ce * Math.sin(cam.az), t[2] + cam.dist * se];
        const f = norm(sub(t, pos));
        const right = norm(cross(f, [0, 0, 1]));
        const up = cross(right, f);
        C = { pos, f, right, up };
    }

    function proj(p) {
        const rel = sub(p, C.pos);
        const zc = dot(rel, C.f);
        if (zc < 0.15) return null;
        return [W / 2 + FPX * dot(rel, C.right) / zc, H / 2 - FPX * dot(rel, C.up) / zc, zc];
    }

    function screenToGround(sx, sy) {
        const u = (sx - W / 2) / FPX, v = -(sy - H / 2) / FPX;
        const d = [C.f[0] + C.right[0] * u + C.up[0] * v, C.f[1] + C.right[1] * u + C.up[1] * v, C.f[2] + C.right[2] * u + C.up[2] * v];
        if (d[2] >= -1e-6) return null;
        const t = -C.pos[2] / d[2];
        const x = C.pos[0] + d[0] * t, y = C.pos[1] + d[1] * t;
        if (x < 0 || y < 0 || x > MAP || y > MAP) return null;
        return [x, y];
    }

    // ---------- geometry builders (produce faces) ----------
    let faces = [];
    const ident = p => p;

    function addFace(vs, color, center, T, twoSided) {
        faces.push({ v: vs.map(T), c: color, ctr: T(center), two: !!twoSided });
    }

    function box(x0, y0, x1, y1, z0, z1, side, top) {
        const ctr = [(x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2];
        const nx = Math.max(1, Math.ceil((x1 - x0) / 1.0)), ny = Math.max(1, Math.ceil((y1 - y0) / 1.0));
        for (let i = 0; i < nx; i++) {
            const a = x0 + (x1 - x0) * i / nx, b = x0 + (x1 - x0) * (i + 1) / nx;
            addFace([[a, y0, z0], [b, y0, z0], [b, y0, z1], [a, y0, z1]], side, ctr, ident);
            addFace([[a, y1, z0], [b, y1, z0], [b, y1, z1], [a, y1, z1]], side, ctr, ident);
            for (let j = 0; j < ny; j++) {
                const c = y0 + (y1 - y0) * j / ny, d = y0 + (y1 - y0) * (j + 1) / ny;
                addFace([[a, c, z1], [b, c, z1], [b, d, z1], [a, d, z1]], top, ctr, ident);
            }
        }
        for (let j = 0; j < ny; j++) {
            const c = y0 + (y1 - y0) * j / ny, d = y0 + (y1 - y0) * (j + 1) / ny;
            addFace([[x0, c, z0], [x0, d, z0], [x0, d, z1], [x0, c, z1]], side, ctr, ident);
            addFace([[x1, c, z0], [x1, d, z0], [x1, d, z1], [x1, c, z1]], side, ctr, ident);
        }
    }

    // vertical cylinder
    function cyl(cx, cy, z0, z1, r, sides, side, top, T) {
        T = T || ident;
        const ctr = [cx, cy, (z0 + z1) / 2];
        const ring = [];
        for (let k = 0; k < sides; k++) { const a = 2 * Math.PI * k / sides; ring.push([cx + r * Math.cos(a), cy + r * Math.sin(a)]); }
        for (let k = 0; k < sides; k++) {
            const p = ring[k], q = ring[(k + 1) % sides];
            addFace([[p[0], p[1], z0], [q[0], q[1], z0], [q[0], q[1], z1], [p[0], p[1], z1]], side, ctr, T);
        }
        addFace(ring.map(p => [p[0], p[1], z1]), top, ctr, T);
    }

    // cylinder whose axis is the local y direction (wheels)
    function wheel(cx, cy, cz, r, w, sides, side, cap, T) {
        const ctr = [cx, cy, cz];
        const A = [], B = [];
        for (let k = 0; k < sides; k++) {
            const a = 2 * Math.PI * k / sides;
            A.push([cx + r * Math.cos(a), cy - w / 2, cz + r * Math.sin(a)]);
            B.push([cx + r * Math.cos(a), cy + w / 2, cz + r * Math.sin(a)]);
        }
        for (let k = 0; k < sides; k++) {
            const n = (k + 1) % sides;
            addFace([A[k], A[n], B[n], B[k]], side, ctr, T);
        }
        addFace(A, cap, ctr, T);
        addFace(B, cap, ctr, T);
    }

    function buildRobot(pose) {
        const b = robotGeo.track_width, wr = robotGeo.wheel_radius;
        const s = ROBOT_VIS_SCALE;
        const th = pose[2], ct = Math.cos(th), st = Math.sin(th);
        // local (robot frame, metres, unscaled) -> world, with visual scale
        const T = p => [pose[0] + s * (p[0] * ct - p[1] * st), pose[1] + s * (p[0] * st + p[1] * ct), s * p[2]];
        const R = Math.max(b * 0.36, 0.06);
        const z0 = Math.max(0.02, wr * 0.6);
        const zTop = z0 + 0.07 + R * 0.35;
        cyl(0, 0, z0, zTop, R, 22, [0, 188, 212], [64, 224, 240], T);                  // chassis
        cyl(0, 0, zTop, zTop + 0.012, R * 0.82, 22, [31, 41, 55], [55, 65, 81], T);   // deck
        cyl(-R * 0.12, 0, zTop + 0.012, zTop + 0.06, R * 0.28, 14, [17, 24, 39], [239, 68, 68], T); // lidar puck
        const zt = zTop + 0.0135;                                                      // heading arrow
        addFace([[R * 0.95, 0, zt], [R * 0.42, R * 0.3, zt], [R * 0.42, -R * 0.3, zt]], [250, 204, 21], [0, 0, zTop], T, true);
        for (const sg of [-1, 1]) wheel(0, sg * (b / 2 + 0.01), wr, wr, 0.04, 16, [55, 55, 66], [120, 120, 135], T);
        cyl(-R * 0.78, 0, 0, z0, 0.02, 8, [156, 163, 175], [156, 163, 175], T);        // caster
    }

    // ---------- drawing ----------
    function shade(c, n, depth) {
        const k = 0.42 + 0.58 * Math.max(0, dot(n, LIGHT));
        const fog = clamp((depth - 14) / 26, 0, 0.35);
        const m = v => Math.round(v * k * (1 - fog) + 14 * fog);
        return "rgb(" + m(c[0]) + "," + m(c[1]) + "," + m(c[2]) + ")";
    }

    function drawFaces() {
        const items = [];
        for (const f of faces) {
            const v = f.v;
            let n = norm(cross(sub(v[1], v[0]), sub(v[2], v[0])));
            const cen = [0, 0, 0];
            for (const p of v) { cen[0] += p[0]; cen[1] += p[1]; cen[2] += p[2]; }
            cen[0] /= v.length; cen[1] /= v.length; cen[2] /= v.length;
            if (!f.two && dot(n, sub(cen, f.ctr)) < 0) n = [-n[0], -n[1], -n[2]];   // make normal point outward
            const toCam = sub(C.pos, cen);
            if (f.two) { if (dot(n, toCam) < 0) n = [-n[0], -n[1], -n[2]]; }
            else if (dot(n, toCam) <= 0) continue;                                    // back-face culling
            const pts = [];
            let ok = true;
            for (const p of v) { const q = proj(p); if (!q) { ok = false; break; } pts.push(q); }
            if (!ok) continue;
            items.push({ pts, n, d: Math.hypot(toCam[0], toCam[1], toCam[2]), c: f.c });
        }
        items.sort((a, b) => b.d - a.d);                                              // far -> near
        for (const it of items) {
            g.beginPath();
            g.moveTo(it.pts[0][0], it.pts[0][1]);
            for (let i = 1; i < it.pts.length; i++) g.lineTo(it.pts[i][0], it.pts[i][1]);
            g.closePath();
            const col = shade(it.c, it.n, it.d);
            g.fillStyle = col; g.strokeStyle = col; g.lineWidth = 0.6;
            g.fill(); g.stroke();
        }
    }

    function line3(pts, z, color, width, dash) {
        g.beginPath();
        g.strokeStyle = color; g.lineWidth = width; g.setLineDash(dash || []);
        let pen = false;
        for (const p of pts) {
            const q = proj([p[0], p[1], z]);
            if (!q) { pen = false; continue; }
            if (!pen) { g.moveTo(q[0], q[1]); pen = true; } else g.lineTo(q[0], q[1]);
        }
        g.stroke(); g.setLineDash([]);
    }

    function ring3(cx, cy, r, color, width, fill) {
        const pts = [];
        for (let k = 0; k <= 36; k++) { const a = 2 * Math.PI * k / 36; pts.push([cx + r * Math.cos(a), cy + r * Math.sin(a)]); }
        if (fill) {
            g.beginPath();
            let pen = false;
            for (const p of pts) { const q = proj([p[0], p[1], 0.01]); if (!q) continue; if (!pen) { g.moveTo(q[0], q[1]); pen = true; } else g.lineTo(q[0], q[1]); }
            g.fillStyle = fill; g.fill();
        }
        line3(pts, 0.01, color, width);
    }

    function shadow(cx, cy, r) {
        const pts = [];
        for (let k = 0; k < 20; k++) { const a = 2 * Math.PI * k / 20; pts.push([cx + 0.1 + r * 1.15 * Math.cos(a), cy + 0.1 + r * 1.15 * Math.sin(a)]); }
        g.beginPath();
        let pen = false;
        for (const p of pts) { const q = proj([p[0], p[1], 0.005]); if (!q) continue; if (!pen) { g.moveTo(q[0], q[1]); pen = true; } else g.lineTo(q[0], q[1]); }
        g.closePath(); g.fillStyle = "rgba(0,0,0,0.38)"; g.fill();
    }

    function drawFloor() {
        for (let i = 0; i < MAP; i++) {
            for (let j = 0; j < MAP; j++) {
                const q = [[i, j], [i + 1, j], [i + 1, j + 1], [i, j + 1]].map(p => proj([p[0], p[1], 0]));
                if (q.some(p => !p)) continue;
                g.beginPath(); g.moveTo(q[0][0], q[0][1]);
                for (let k = 1; k < 4; k++) g.lineTo(q[k][0], q[k][1]);
                g.closePath();
                const col = (i + j) % 2 ? "#17233a" : "#1b2a44";
                g.fillStyle = col; g.strokeStyle = col; g.lineWidth = 0.6; g.fill(); g.stroke();
            }
        }
    }

    function render(data, startPt) {
        if (!cv) return;
        if (data) last = data;
        if (startPt) lastStart = startPt;
        data = last;
        updateCamera(data);

        // sky background
        const grad = g.createLinearGradient(0, 0, 0, H);
        grad.addColorStop(0, "#050a14"); grad.addColorStop(1, "#16233a");
        g.fillStyle = grad; g.fillRect(0, 0, W, H);

        drawFloor();
        if (!data) return;

        // ground-level features (always correctly hidden by solids drawn afterwards)
        (data.dynamic_obstacles || []).forEach(o => shadow(o.pos[0], o.pos[1], o.radius));
        if (data.pose) shadow(data.pose[0], data.pose[1], 0.2);
        if (data.global_path && data.global_path.length > 1) line3(data.global_path, 0.02, "#ffd600", 3, [9, 6]);
        if (data.trajectory && data.trajectory.length > 1) line3(data.trajectory, 0.025, "#e100ff", 3);
        if (data.lidar_ranges && data.pose) {
            const n = data.lidar_ranges.length, th = data.pose[2];
            g.strokeStyle = "rgba(0,242,254,0.22)"; g.lineWidth = 1;
            for (let i = 0; i < n; i += 2) {
                const a = th + (-Math.PI + i * 2 * Math.PI / n), d = data.lidar_ranges[i];
                const p0 = proj([data.pose[0], data.pose[1], 0.12]);
                const p1 = proj([data.pose[0] + d * Math.cos(a), data.pose[1] + d * Math.sin(a), 0.12]);
                if (p0 && p1) { g.beginPath(); g.moveTo(p0[0], p0[1]); g.lineTo(p1[0], p1[1]); g.stroke(); }
            }
        }
        ring3(lastStart[0], lastStart[1], 0.32, "#2979ff", 3, "rgba(41,121,255,0.30)");
        if (data.goal) ring3(data.goal[0], data.goal[1], 0.42, "#00e676", 3, "rgba(0,230,118,0.28)");
        (data.dynamic_obstacles || []).forEach(o => {
            if (o.vel) line3([o.pos, [o.pos[0] + o.vel[0] * 1.5, o.pos[1] + o.vel[1] * 1.5]], 0.03, "#ffd600", 3);
        });

        // solid objects
        faces = [];
        rects.forEach(r => r.border
            ? box(r.x0, r.y0, r.x1, r.y1, 0, 0.45, [100, 116, 139], [148, 163, 184])
            : box(r.x0, r.y0, r.x1, r.y1, 0, 0.95, [120, 98, 170], [176, 156, 222]));
        (data.dynamic_obstacles || []).forEach(o => {
            cyl(o.pos[0], o.pos[1], 0, 0.7, o.radius, 16, [220, 60, 60], [255, 120, 120]);
            cyl(o.pos[0], o.pos[1], 0.7, 0.78, o.radius * 0.6, 12, [255, 200, 70], [255, 230, 120]);
        });
        if (data.goal) {                                        // goal flag
            const gx = data.goal[0], gy = data.goal[1];
            cyl(gx, gy, 0, 1.2, 0.03, 8, [230, 230, 230], [230, 230, 230]);
            addFace([[gx, gy, 1.2], [gx + 0.45, gy, 1.02], [gx, gy, 0.84]], [0, 230, 118], [gx, gy, 1.0], ident, true);
        }
        if (data.pose) buildRobot(data.pose);
        drawFaces();

        // HUD
        g.fillStyle = "rgba(255,255,255,0.75)"; g.font = "12px sans-serif";
        g.fillText("3D view: " + cam.mode + "  |  drag = rotate, wheel = zoom", 10, H - 10);
    }

    // ---------- interaction ----------
    function init(canvas) {
        cv = canvas; g = cv.getContext("2d"); W = cv.width; H = cv.height;
        FPX = (H / 2) / Math.tan(25 * Math.PI / 180);
        let drag = null;
        cv.addEventListener("mousedown", e => { drag = { x: e.clientX, y: e.clientY, moved: 0 }; });
        window.addEventListener("mouseup", e => {
            if (drag && drag.moved < 4 && api.onGroundClick) {
                const r = cv.getBoundingClientRect();
                const pt = screenToGround((e.clientX - r.left) * W / r.width, (e.clientY - r.top) * H / r.height);
                if (pt) api.onGroundClick(pt);
            }
            drag = null;
        });
        window.addEventListener("mousemove", e => {
            if (!drag) return;
            const dx = e.clientX - drag.x, dy = e.clientY - drag.y;
            drag.moved += Math.abs(dx) + Math.abs(dy);
            drag.x = e.clientX; drag.y = e.clientY;
            if (drag.moved >= 4) {
                cam.mode = "orbit";
                cam.az -= dx * 0.008;
                cam.el = clamp(cam.el + dy * 0.006, 0.12, 1.50);
                render();
            }
        });
        cv.addEventListener("wheel", e => {
            e.preventDefault();
            cam.dist = clamp(cam.dist * (e.deltaY > 0 ? 1.1 : 0.9), 2.5, 24);
            cam.mode = "orbit";
            render();
        }, { passive: false });
    }

    function setMode(m) {
        cam.mode = m;
        if (m === "orbit") { cam.az = -Math.PI / 2; cam.el = 0.62; cam.dist = 15.5; }
        render();
    }

    if (!window.View3D) window.View3D = {
        init,
        setGrid: grid => { rects = buildRects(grid); },
        setRobot: geo => { if (geo) robotGeo = geo; },
        render,
        remember: (d, st) => { last = d; if (st) lastStart = st; },
        redraw: () => render(),
        setMode,
        set onGroundClick(fn) { api.onGroundClick = fn; },
        get onGroundClick() { return api.onGroundClick; },
    };
})();
