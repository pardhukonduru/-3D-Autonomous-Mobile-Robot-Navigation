// AMR Navigation Interactive Visualizer & Telemetry Dashboard

document.addEventListener("DOMContentLoaded", () => {
    const canvas = document.getElementById("sim-canvas");
    const ctx = canvas.getContext("2d");
    const MAP_SIZE_M = 10.0;
    const SCALE = canvas.width / MAP_SIZE_M; // Pixels per meter

    let isRunning = false;
    let animFrameId = null;
    let stepInFlight = false;
    let lastErrorMessage = "";

    // User-selectable start / goal points (metres). Defaults match the original setup.
    const DEFAULT_START = [1.0, 1.0];
    const DEFAULT_GOAL = [9.0, 9.0];
    let startPoint = DEFAULT_START.slice();
    let goalPoint = DEFAULT_GOAL.slice();
    let pickMode = null; // "start" | "goal" | null
    let view3dOn = false;

    function showNotice(message, isError = true) {
        let box = document.getElementById("sim-notice");
        if (!box) {
            box = document.createElement("div");
            box.id = "sim-notice";
            box.style.cssText = "position:fixed;left:50%;top:18px;transform:translateX(-50%);z-index:9999;color:#fff;border-radius:8px;padding:10px 16px;font:14px sans-serif;max-width:80%;box-shadow:0 4px 18px rgba(0,0,0,.4);";
            document.body.appendChild(box);
        }
        box.style.background = isError ? "#3b0d0d" : "#0d3b1d";
        box.style.border = isError ? "1px solid #ff5252" : "1px solid #00e676";
        box.textContent = message;
        box.style.display = "block";
        clearTimeout(box._t);
        box._t = setTimeout(() => { box.style.display = "none"; }, 3500);
    }

    function syncPointInputs() {
        document.getElementById("in-start-x").value = startPoint[0].toFixed(1);
        document.getElementById("in-start-y").value = startPoint[1].toFixed(1);
        document.getElementById("in-goal-x").value = goalPoint[0].toFixed(1);
        document.getElementById("in-goal-y").value = goalPoint[1].toFixed(1);
    }

    // Charts Setup
    const ctxTorques = document.getElementById("chart-torques").getContext("2d");
    const ctxVelocities = document.getElementById("chart-velocities").getContext("2d");

    const chartTorques = new Chart(ctxTorques, {
        type: 'line',
        data: {
            labels: [],
            datasets: [
                { label: 'Tau Left (Nm)', data: [], borderColor: '#00f2fe', borderWidth: 1.5, pointRadius: 0 },
                { label: 'Tau Right (Nm)', data: [], borderColor: '#e100ff', borderWidth: 1.5, pointRadius: 0 }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            animation: false,
            scales: {
                x: { display: false },
                y: { ticks: { color: '#8a99ad', font: { size: 10 } }, grid: { color: 'rgba(255,255,255,0.05)' } }
            },
            plugins: { legend: { labels: { color: '#f0f4f8', font: { size: 10 } } } }
        }
    });

    const chartVelocities = new Chart(ctxVelocities, {
        type: 'line',
        data: {
            labels: [],
            datasets: [
                { label: 'Linear v (m/s)', data: [], borderColor: '#00e676', borderWidth: 1.5, pointRadius: 0 },
                { label: 'Angular w (rad/s)', data: [], borderColor: '#ffd600', borderWidth: 1.5, pointRadius: 0 }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            animation: false,
            scales: {
                x: { display: false },
                y: { ticks: { color: '#8a99ad', font: { size: 10 } }, grid: { color: 'rgba(255,255,255,0.05)' } }
            },
            plugins: { legend: { labels: { color: '#f0f4f8', font: { size: 10 } } } }
        }
    });

    // API Calls
    async function fetchJson(url, options = {}, timeoutMs = 5000) {
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), timeoutMs);
        try {
            const res = await fetch(url, { ...options, signal: controller.signal });
            const text = await res.text();
            let data;
            try { data = JSON.parse(text); }
            catch (_) { throw new Error(`Server returned non-JSON response (${res.status})`); }
            if (!res.ok || data.error) {
                throw new Error(data.error || `HTTP ${res.status}`);
            }
            return data;
        } finally {
            clearTimeout(timer);
        }
    }

    function showConnectionError(message) {
        lastErrorMessage = message;
        let box = document.getElementById("sim-error");
        if (!box) {
            box = document.createElement("div");
            box.id = "sim-error";
            box.style.cssText = "position:fixed;left:50%;bottom:18px;transform:translateX(-50%);z-index:9999;background:#3b0d0d;color:#fff;border:1px solid #ff5252;border-radius:8px;padding:10px 16px;font:14px sans-serif;max-width:80%;box-shadow:0 4px 18px rgba(0,0,0,.4);";
            document.body.appendChild(box);
        }
        box.textContent = `Simulation connection error: ${message}. Retrying...`;
        box.style.display = "block";
    }

    function clearConnectionError() {
        const box = document.getElementById("sim-error");
        if (box) box.style.display = "none";
        lastErrorMessage = "";
    }

    async function initSim() {
        const robot = document.getElementById("select-robot").value;
        const globalPlanner = document.getElementById("select-global-planner").value;
        const localPlanner = document.getElementById("select-local-planner").value;
        const controller = document.getElementById("select-controller").value;

        try {
            const data = await fetchJson("/api/init", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    robot: robot,
                    global_planner: globalPlanner,
                    local_planner: localPlanner,
                    controller: controller,
                    start: startPoint,
                    goal: goalPoint
                })
            });
            clearConnectionError();
            if (window.View3D) { View3D.setGrid(data.grid); View3D.setRobot(data.robot_geometry); }
            renderState(data);
            updateTelemetry(data);
            if (data.planner_used && data.planner_used.includes("fallback")) {
                showNotice("Planner fell back to A*: " + data.planner_used, true);
            }
            return true;
        } catch (err) {
            if (err.name === "AbortError") showConnectionError("server timeout");
            else showNotice(err.message, true);
            return false;
        }
    }

    // Try new start/goal; if the server rejects them, keep the previous valid ones.
    async function applyPoints(newStart, newGoal) {
        const prevStart = startPoint, prevGoal = goalPoint;
        isRunning = false;
        if (animFrameId) clearTimeout(animFrameId);
        startPoint = newStart; goalPoint = newGoal;
        const ok = await initSim(true);
        if (!ok) {
            startPoint = prevStart; goalPoint = prevGoal;
            syncPointInputs();
            await initSim(true);
        } else {
            syncPointInputs();
            showNotice("Start/goal updated.", false);
        }
    }

    async function stepSim() {
        if (!isRunning || stepInFlight) return;
        stepInFlight = true;

        const localPlanner = document.getElementById("select-local-planner").value;
        const controller = document.getElementById("select-controller").value;
        const speedRegulator = parseFloat(document.getElementById("range-speed").value);

        try {
            const data = await fetchJson("/api/step", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    local_planner: localPlanner,
                    controller: controller,
                    speed_regulator: speedRegulator,
                    dt: 0.05
                })
            }, 5000);

            clearConnectionError();
            renderState(data);
            updateTelemetry(data);

            if (data.done) {
                isRunning = false;
                stepInFlight = false;
                if (data.collision) {
                    alert("⚠️ Simulation Terminated: Collision Detected!");
                } else {
                    alert("🎯 Goal Reached Successfully!");
                }
                return;
            }
        } catch (err) {
            showConnectionError(err.name === "AbortError" ? "server timeout" : err.message);
            // Keep the simulation alive. A transient browser/server delay no longer
            // silently kills the animation loop.
        } finally {
            stepInFlight = false;
        }

        if (isRunning) {
            // Run at the same 20 Hz rate as the physics timestep. This is much more
            // reliable than sending requests as fast as requestAnimationFrame fires.
            animFrameId = setTimeout(stepSim, 50);
        }
    }

    function renderState(data) {
        if (window.View3D) { if (view3dOn) View3D.render(data, startPoint); else View3D.remember(data, startPoint); }
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        // 1. Draw Static Grid Map
        if (data.grid) {
            const rows = data.grid.length;
            const cols = data.grid[0].length;
            const cellW = canvas.width / cols;
            const cellH = canvas.height / rows;

            for (let r = 0; r < rows; r++) {
                for (let c = 0; c < cols; c++) {
                    if (data.grid[r][c] === 1) {
                        ctx.fillStyle = "#2d3748";
                        ctx.fillRect(c * cellW, r * cellH, cellW, cellH);
                    }
                }
            }
        }

        // 2. Draw Global Path
        if (data.global_path && data.global_path.length > 1) {
            ctx.beginPath();
            ctx.setLineDash([5, 5]);
            ctx.strokeStyle = "#ffd600";
            ctx.lineWidth = 2;
            ctx.moveTo(data.global_path[0][0] * SCALE, data.global_path[0][1] * SCALE);
            for (let i = 1; i < data.global_path.length; i++) {
                ctx.lineTo(data.global_path[i][0] * SCALE, data.global_path[i][1] * SCALE);
            }
            ctx.stroke();
            ctx.setLineDash([]);
        }

        // 3. Draw Historical Trajectory
        if (data.trajectory && data.trajectory.length > 1) {
            ctx.beginPath();
            ctx.strokeStyle = "#e100ff";
            ctx.lineWidth = 2.5;
            ctx.moveTo(data.trajectory[0][0] * SCALE, data.trajectory[0][1] * SCALE);
            for (let i = 1; i < data.trajectory.length; i++) {
                ctx.lineTo(data.trajectory[i][0] * SCALE, data.trajectory[i][1] * SCALE);
            }
            ctx.stroke();
        }

        // 4. Draw Goal Point
        if (data.goal) {
            const gx = data.goal[0] * SCALE;
            const gy = data.goal[1] * SCALE;
            ctx.beginPath();
            ctx.arc(gx, gy, 10, 0, 2 * Math.PI);
            ctx.fillStyle = "#00e676";
            ctx.fill();
            ctx.strokeStyle = "#ffffff";
            ctx.lineWidth = 2;
            ctx.stroke();
        }

        // 4b. Draw Start Point (user-selectable)
        {
            const sx = startPoint[0] * SCALE, sy = startPoint[1] * SCALE;
            ctx.beginPath();
            ctx.arc(sx, sy, 8, 0, 2 * Math.PI);
            ctx.fillStyle = "#2979ff";
            ctx.fill();
            ctx.strokeStyle = "#ffffff";
            ctx.lineWidth = 2;
            ctx.stroke();
        }

        // 5. Draw Dynamic Obstacles
        if (data.dynamic_obstacles) {
            data.dynamic_obstacles.forEach(obs => {
                const ox = obs.pos[0] * SCALE;
                const oy = obs.pos[1] * SCALE;
                const r = obs.radius * SCALE;

                ctx.beginPath();
                ctx.arc(ox, oy, r, 0, 2 * Math.PI);
                ctx.fillStyle = "#ff5252";
                ctx.fill();
                ctx.strokeStyle = "#ffffff";
                ctx.lineWidth = 1.5;
                ctx.stroke();

                // Velocity vector arrow
                if (obs.vel) {
                    ctx.beginPath();
                    ctx.moveTo(ox, oy);
                    ctx.lineTo(ox + obs.vel[0] * SCALE * 1.5, oy + obs.vel[1] * SCALE * 1.5);
                    ctx.strokeStyle = "#ffd600";
                    ctx.lineWidth = 2;
                    ctx.stroke();
                }
            });
        }

        // 6. Draw Lidar Rays
        if (data.lidar_ranges && data.pose) {
            const rx = data.pose[0] * SCALE;
            const ry = data.pose[1] * SCALE;
            const theta = data.pose[2];
            const numBeams = data.lidar_ranges.length;

            ctx.strokeStyle = "rgba(0, 242, 254, 0.25)";
            ctx.lineWidth = 1;

            for (let i = 0; i < numBeams; i++) {
                const angle = theta + (-Math.PI + (i * 2 * Math.PI / numBeams));
                const dist = data.lidar_ranges[i] * SCALE;
                ctx.beginPath();
                ctx.moveTo(rx, ry);
                ctx.lineTo(rx + dist * Math.cos(angle), ry + dist * Math.sin(angle));
                ctx.stroke();
            }
        }

        // 7. Draw Robot Body
        if (data.pose) {
            const rx = data.pose[0] * SCALE;
            const ry = data.pose[1] * SCALE;
            const theta = data.pose[2];

            ctx.save();
            ctx.translate(rx, ry);
            ctx.rotate(theta);

            // Robot chassis circle
            ctx.beginPath();
            ctx.arc(0, 0, 14, 0, 2 * Math.PI);
            ctx.fillStyle = "#00f2fe";
            ctx.fill();
            ctx.strokeStyle = "#ffffff";
            ctx.lineWidth = 2;
            ctx.stroke();

            // Drive wheels
            ctx.fillStyle = "#111111";
            ctx.fillRect(-6, -18, 12, 5); // Left wheel
            ctx.fillRect(-6, 13, 12, 5);  // Right wheel

            // Heading pointer
            ctx.beginPath();
            ctx.moveTo(0, 0);
            ctx.lineTo(18, 0);
            ctx.strokeStyle = "#050b14";
            ctx.lineWidth = 3;
            ctx.stroke();

            ctx.restore();
        }

        // Update Sim Timer
        if (data.sim_time !== undefined) {
            document.getElementById("sim-timer").innerText = `Time: ${data.sim_time.toFixed(2)} s`;
        }
    }

    function updateTelemetry(data) {
        if (!data.telemetry) return;

        const tel = data.telemetry;
        const lastIdx = tel.time.length - 1;
        if (lastIdx < 0) return;

        document.getElementById("telemetry-v").innerText = `${tel.v[lastIdx].toFixed(2)} m/s`;
        document.getElementById("telemetry-omega").innerText = `${tel.omega[lastIdx].toFixed(2)} rad/s`;
        document.getElementById("telemetry-torques").innerText = `${tel.tau_l[lastIdx].toFixed(2)} / ${tel.tau_r[lastIdx].toFixed(2)} Nm`;
        document.getElementById("telemetry-error").innerText = `${Math.hypot(tel.e_x[lastIdx], tel.e_y[lastIdx]).toFixed(3)} m`;
        document.getElementById("telemetry-energy").innerText = `${tel.energy[lastIdx].toFixed(2)} J`;

        // Update Adapted ANFIS Params
        if (data.adapted_params) {
            document.getElementById("val-krep").innerText = data.adapted_params.k_rep.toFixed(2);
            document.getElementById("val-d0").innerText = `${data.adapted_params.d_0.toFixed(2)}m`;
            document.getElementById("val-vscale").innerText = `${(data.adapted_params.v_max / 0.5 * 100).toFixed(0)}%`;

            const statusBadge = document.getElementById("val-adapt-status");
            if (data.adapted_params.adaptation_active) {
                statusBadge.innerText = "ACTIVE";
                statusBadge.style.color = "#00e676";
            } else {
                statusBadge.innerText = "Baseline";
                statusBadge.style.color = "#00f2fe";
            }
        }

        // Update Charts
        chartTorques.data.labels = tel.time;
        chartTorques.data.datasets[0].data = tel.tau_l;
        chartTorques.data.datasets[1].data = tel.tau_r;
        chartTorques.update();

        chartVelocities.data.labels = tel.time;
        chartVelocities.data.datasets[0].data = tel.v;
        chartVelocities.data.datasets[1].data = tel.omega;
        chartVelocities.update();
    }

    // Start / Goal selection (click on map, or type coordinates)
    function setPickMode(mode) {
        pickMode = (pickMode === mode) ? null : mode;
        document.getElementById("btn-pick-start").style.outline = pickMode === "start" ? "2px solid #2979ff" : "";
        document.getElementById("btn-pick-goal").style.outline = pickMode === "goal" ? "2px solid #00e676" : "";
        canvas.style.cursor = pickMode ? "crosshair" : "default";
        document.getElementById("pick-hint").textContent = pickMode
            ? `Click on the map to place the ${pickMode}.` : "Tip: press Set Start / Set Goal, then click the map.";
    }
    document.getElementById("btn-pick-start").addEventListener("click", () => setPickMode("start"));
    document.getElementById("btn-pick-goal").addEventListener("click", () => setPickMode("goal"));

    async function handlePick(x, y) {
        if (!pickMode) return;
        const pt = [Math.round(x * 10) / 10, Math.round(y * 10) / 10];
        const mode = pickMode;
        setPickMode(mode); // leave pick mode after one click
        await applyPoints(mode === "start" ? pt : startPoint, mode === "goal" ? pt : goalPoint);
    }

    canvas.addEventListener("click", (ev) => {
        const rect = canvas.getBoundingClientRect();
        handlePick((ev.clientX - rect.left) * (canvas.width / rect.width) / SCALE,
                   (ev.clientY - rect.top) * (canvas.height / rect.height) / SCALE);
    });

    // ---- 2D / 3D view switch ----
    const canvas3d = document.getElementById("sim-canvas-3d");
    if (window.View3D) {
        View3D.init(canvas3d);
        View3D.onGroundClick = (pt) => handlePick(pt[0], pt[1]);
    }
    function setView(is3d) {
        view3dOn = is3d && !!window.View3D;
        canvas.style.display = view3dOn ? "none" : "block";
        canvas3d.style.display = view3dOn ? "block" : "none";
        document.getElementById("cam-modes").style.display = view3dOn ? "flex" : "none";
        document.getElementById("btn-view-2d").className = "btn " + (view3dOn ? "btn-secondary" : "btn-primary");
        document.getElementById("btn-view-3d").className = "btn " + (view3dOn ? "btn-primary" : "btn-secondary");
        if (view3dOn) View3D.redraw();
    }
    document.getElementById("btn-view-2d").addEventListener("click", () => setView(false));
    document.getElementById("btn-view-3d").addEventListener("click", () => setView(true));
    document.querySelectorAll(".cam-mode").forEach(b =>
        b.addEventListener("click", () => { if (window.View3D) View3D.setMode(b.dataset.mode); }));

    document.getElementById("btn-apply-points").addEventListener("click", async () => {
        const v = id => parseFloat(document.getElementById(id).value);
        const ns = [v("in-start-x"), v("in-start-y")], ng = [v("in-goal-x"), v("in-goal-y")];
        if ([...ns, ...ng].some(Number.isNaN)) { showNotice("Enter numeric coordinates."); return; }
        await applyPoints(ns, ng);
    });
    document.getElementById("btn-default-points").addEventListener("click", async () => {
        await applyPoints(DEFAULT_START.slice(), DEFAULT_GOAL.slice());
    });

    // Button Listeners
    document.getElementById("btn-start").addEventListener("click", () => {
        if (!isRunning) {
            isRunning = true;
            stepSim();
        }
    });

    document.getElementById("btn-pause").addEventListener("click", () => {
        isRunning = false;
        if (animFrameId) clearTimeout(animFrameId);
    });

    document.getElementById("btn-reset").addEventListener("click", async () => {
        isRunning = false;
        if (animFrameId) clearTimeout(animFrameId);
        await initSim();
    });

    // Config Dropdown Change Listener
    ["select-robot", "select-global-planner", "select-local-planner", "select-controller"].forEach(id => {
        document.getElementById(id).addEventListener("change", async () => {
            isRunning = false;
            if (animFrameId) clearTimeout(animFrameId);
            await initSim();
        });
    });

    // Speed Regulator Listeners
    const speedSelect = document.getElementById("select-speed-preset");
    const speedSlider = document.getElementById("range-speed");
    const speedLabel = document.getElementById("val-speed-slider");

    if (speedSelect && speedSlider) {
        speedSelect.addEventListener("change", (e) => {
            const val = e.target.value;
            if (val !== "custom") {
                speedSlider.value = val;
                speedLabel.innerText = `${parseFloat(val).toFixed(2)} m/s`;
            }
        });

        speedSlider.addEventListener("input", (e) => {
            speedLabel.innerText = `${parseFloat(e.target.value).toFixed(2)} m/s`;
            speedSelect.value = "custom";
        });
    }

    // Benchmark Modal Trigger
    const modal = document.getElementById("benchmark-modal");
    document.getElementById("btn-benchmark").addEventListener("click", async () => {
        modal.style.display = "flex";
        const tbody = document.getElementById("benchmark-body");
        tbody.innerHTML = `<tr><td colspan="7" style="text-align:center;">Running multi-trial benchmark matrix... Please wait...</td></tr>`;

        try {
            const results = await fetchJson("/api/benchmark", { method: "POST" }, 120000);

        let html = "";
        for (const [name, m] of Object.entries(results)) {
            html += `
                <tr>
                    <td><strong>${name}</strong></td>
                    <td><span style="color:${m.success_rate_percent >= 80 ? '#00e676' : '#ff5252'}">${m.success_rate_percent.toFixed(0)}%</span></td>
                    <td>${m.mean_path_length_m.toFixed(2)}</td>
                    <td>${m.mean_smoothness.toFixed(3)}</td>
                    <td>${m.mean_convergence_time_s.toFixed(2)}</td>
                    <td>${m.mean_comp_time_per_step_ms.toFixed(2)}</td>
                    <td>${m.mean_torque_energy_J.toFixed(3)}</td>
                </tr>
            `;
        }
        tbody.innerHTML = html;
        } catch (err) {
            tbody.innerHTML = `<tr><td colspan="7" style="text-align:center;color:#ff5252;">Benchmark error: ${err.message}</td></tr>`;
        }
    });

    document.querySelector(".close-modal").addEventListener("click", () => {
        modal.style.display = "none";
    });

    // Initialize on load
    initSim();
});
