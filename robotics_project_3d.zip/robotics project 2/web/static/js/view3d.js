/*
 * view3d.js - REAL 3D (WebGL / three.js) view of the simulation.
 * Real lighting, soft shadows, depth buffer, antialiasing, fog.
 * Same public API as before: init, setGrid, setRobot, render, remember,
 * redraw, setMode, onGroundClick.  World frame: x right, y forward, z up (m).
 * If three.js cannot load (offline), view3d_fallback.js is used instead.
 */
(function () {
    "use strict";
    if (!window.THREE) { console.warn("three.js not loaded - using fallback 3D view"); return; }
    const T = window.THREE;

    const MAP = 10.0, VIS = 3.0;
    const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
    const wrapPi = a => { while (a > Math.PI) a -= 2 * Math.PI; while (a < -Math.PI) a += 2 * Math.PI; return a; };

    let cv, renderer, scene, camera, ray;
    let W = 600, H = 600;
    let staticGroup, robot, goalGroup, startRing, pathLine, trailLine, lidarLines, obsGroup;
    let rects = [], robotGeo = { track_width: 0.16, wheel_radius: 0.033 };
    let last = null, lastStart = [1, 1], robotDirty = true, obsPool = [];
    const cam = { az: -Math.PI / 2, el: 0.62, dist: 15.5, target: new T.Vector3(5, 5, 0), mode: "orbit" };
    const api = { onGroundClick: null };

    const mat = (c, o) => new T.MeshStandardMaterial(Object.assign({ color: c, roughness: 0.6, metalness: 0.15 }, o || {}));

    function floorTexture() {
        const c = document.createElement("canvas"); c.width = c.height = 1024;
        const g = c.getContext("2d"), s = 1024 / MAP;
        for (let i = 0; i < MAP; i++) for (let j = 0; j < MAP; j++) {
            g.fillStyle = (i + j) % 2 ? "#1b2a44" : "#223556"; g.fillRect(i * s, (MAP - 1 - j) * s, s, s);
        }
        g.strokeStyle = "rgba(120,160,220,0.25)"; g.lineWidth = 2;
        for (let k = 0; k <= MAP; k++) {
            g.beginPath(); g.moveTo(k * s, 0); g.lineTo(k * s, 1024); g.stroke();
            g.beginPath(); g.moveTo(0, k * s); g.lineTo(1024, k * s); g.stroke();
        }
        const t = new T.CanvasTexture(c); t.anisotropy = 8; return t;
    }

    function init(canvas) {
        cv = canvas; W = cv.width; H = cv.height;
        renderer = new T.WebGLRenderer({ canvas: cv, antialias: true, alpha: false });
        renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
        renderer.setSize(W, H, false);
        cv.style.width = W + "px"; cv.style.height = H + "px";
        renderer.shadowMap.enabled = true; renderer.shadowMap.type = T.PCFSoftShadowMap;
        renderer.setClearColor(0x0a1322);

        scene = new T.Scene();
        scene.fog = new T.Fog(0x0a1322, 18, 42);
        camera = new T.PerspectiveCamera(50, W / H, 0.1, 100);
        camera.up.set(0, 0, 1);
        ray = new T.Raycaster();

        scene.add(new T.HemisphereLight(0xbfd4ff, 0x1a2338, 0.75));
        const sun = new T.DirectionalLight(0xffffff, 1.0);
        sun.position.set(2, -3, 12); sun.target.position.set(5, 5, 0);
        sun.castShadow = true; sun.shadow.mapSize.set(2048, 2048);
        const sc = sun.shadow.camera; sc.left = -9; sc.right = 9; sc.top = 9; sc.bottom = -9; sc.near = 1; sc.far = 40;
        sun.shadow.bias = -0.0004;
        scene.add(sun, sun.target);

        const floor = new T.Mesh(new T.PlaneGeometry(MAP, MAP), new T.MeshStandardMaterial({ map: floorTexture(), roughness: 0.9 }));
        floor.position.set(MAP / 2, MAP / 2, 0); floor.receiveShadow = true; floor.name = "floor";
        scene.add(floor);
        const ground = new T.Mesh(new T.PlaneGeometry(80, 80), new T.MeshBasicMaterial({ color: 0x0a1322 }));
        ground.position.set(5, 5, -0.02); scene.add(ground);

        staticGroup = new T.Group(); obsGroup = new T.Group(); scene.add(staticGroup, obsGroup);

        // goal flag + rings
        goalGroup = new T.Group();
        const pole = new T.Mesh(new T.CylinderGeometry(0.03, 0.03, 1.2, 10), mat(0xe5e7eb)); pole.rotation.x = Math.PI / 2; pole.position.z = 0.6; pole.castShadow = true;
        const shp = new T.Shape(); shp.moveTo(0, 0.18); shp.lineTo(0.45, 0); shp.lineTo(0, -0.18);
        const flag = new T.Mesh(new T.ShapeGeometry(shp), new T.MeshStandardMaterial({ color: 0x00e676, side: T.DoubleSide, emissive: 0x006633 }));
        flag.rotation.x = Math.PI / 2; flag.position.set(0, 0, 1.02); flag.castShadow = true;
        const gring = new T.Mesh(new T.RingGeometry(0.34, 0.44, 40), new T.MeshBasicMaterial({ color: 0x00e676, transparent: true, opacity: 0.8, side: T.DoubleSide }));
        gring.position.z = 0.012;
        goalGroup.add(pole, flag, gring); goalGroup.visible = false; scene.add(goalGroup);
        startRing = new T.Mesh(new T.RingGeometry(0.24, 0.34, 40), new T.MeshBasicMaterial({ color: 0x2979ff, transparent: true, opacity: 0.85, side: T.DoubleSide }));
        startRing.position.z = 0.012; scene.add(startRing);

        // dynamic lines
        pathLine = new T.Line(new T.BufferGeometry(), new T.LineDashedMaterial({ color: 0xffd600, dashSize: 0.18, gapSize: 0.12 }));
        trailLine = new T.Line(new T.BufferGeometry(), new T.LineBasicMaterial({ color: 0xe100ff }));
        lidarLines = new T.LineSegments(new T.BufferGeometry(), new T.LineBasicMaterial({ color: 0x00f2fe, transparent: true, opacity: 0.35 }));
        [pathLine, trailLine, lidarLines].forEach(l => { l.frustumCulled = false; scene.add(l); });

        // interaction
        let drag = null;
        cv.addEventListener("mousedown", e => { drag = { x: e.clientX, y: e.clientY, moved: 0 }; });
        window.addEventListener("mouseup", e => {
            if (drag && drag.moved < 4 && api.onGroundClick) {
                const r = cv.getBoundingClientRect();
                const pt = pick((e.clientX - r.left) / r.width, (e.clientY - r.top) / r.height);
                if (pt) api.onGroundClick(pt);
            }
            drag = null;
        });
        window.addEventListener("mousemove", e => {
            if (!drag) return;
            const dx = e.clientX - drag.x, dy = e.clientY - drag.y;
            drag.moved += Math.abs(dx) + Math.abs(dy); drag.x = e.clientX; drag.y = e.clientY;
            if (drag.moved >= 4) { cam.mode = "orbit"; cam.az -= dx * 0.008; cam.el = clamp(cam.el + dy * 0.006, 0.08, 1.52); render(); }
        });
        cv.addEventListener("wheel", e => {
            e.preventDefault(); cam.dist = clamp(cam.dist * (e.deltaY > 0 ? 1.1 : 0.9), 2.0, 26); cam.mode = "orbit"; render();
        }, { passive: false });
        // touch (rotate with one finger)
        let tp = null;
        cv.addEventListener("touchstart", e => { if (e.touches.length === 1) tp = [e.touches[0].clientX, e.touches[0].clientY]; }, { passive: true });
        cv.addEventListener("touchmove", e => {
            if (!tp || e.touches.length !== 1) return; e.preventDefault();
            const x = e.touches[0].clientX, y = e.touches[0].clientY;
            cam.mode = "orbit"; cam.az -= (x - tp[0]) * 0.008; cam.el = clamp(cam.el + (y - tp[1]) * 0.006, 0.08, 1.52); tp = [x, y]; render();
        }, { passive: false });
        cv.addEventListener("touchend", () => { tp = null; });
    }

    function pick(nx, ny) {
        ray.setFromCamera(new T.Vector2(nx * 2 - 1, -(ny * 2 - 1)), camera);
        const o = ray.ray.origin, d = ray.ray.direction;
        if (d.z >= -1e-6) return null;
        const t = -o.z / d.z, x = o.x + d.x * t, y = o.y + d.y * t;
        return (x < 0 || y < 0 || x > MAP || y > MAP) ? null : [x, y];
    }

    // ---------- static map ----------
    function buildRects(grid) {
        const rows = grid.length, cols = grid[0].length, res = MAP / cols;
        const seen = grid.map(r => r.map(() => false)), out = [];
        for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) {
            if (grid[r][c] !== 1 || seen[r][c]) continue;
            let w = 1; while (c + w < cols && grid[r][c + w] === 1 && !seen[r][c + w]) w++;
            let h = 1, ok = true;
            while (r + h < rows && ok) { for (let k = 0; k < w; k++) if (grid[r + h][c + k] !== 1 || seen[r + h][c + k]) { ok = false; break; } if (ok) h++; }
            for (let i = 0; i < h; i++) for (let k = 0; k < w; k++) seen[r + i][c + k] = true;
            const x0 = (c - 0.5) * res, x1 = (c + w - 0.5) * res, y0 = (r - 0.5) * res, y1 = (r + h - 0.5) * res;
            out.push({ x0, y0, x1, y1, border: x0 <= 0.06 || y0 <= 0.06 || x1 >= MAP - 0.15 || y1 >= MAP - 0.15 });
        }
        return out;
    }

    function disposeGroup(g) {
        while (g.children.length) { const m = g.children.pop(); if (m.geometry) m.geometry.dispose(); }
    }

    function rebuildStatic() {
        if (!staticGroup) return;
        disposeGroup(staticGroup);
        const wallM = mat(0x64748b, { roughness: 0.8 }), pilM = mat(0x8b78c4, { roughness: 0.45 });
        const edge = new T.LineBasicMaterial({ color: 0x1e1b3a, transparent: true, opacity: 0.6 });
        rects.forEach(r => {
            const h = r.border ? 0.45 : 0.95, w = r.x1 - r.x0, d = r.y1 - r.y0;
            const geo = new T.BoxGeometry(w, d, h);
            const m = new T.Mesh(geo, r.border ? wallM : pilM);
            m.position.set(r.x0 + w / 2, r.y0 + d / 2, h / 2); m.castShadow = true; m.receiveShadow = true;
            staticGroup.add(m);
            const e = new T.LineSegments(new T.EdgesGeometry(geo), edge); e.position.copy(m.position); staticGroup.add(e);
        });
    }

    // ---------- robot ----------
    function buildRobot() {
        if (robot) { scene.remove(robot); robot.traverse(o => o.geometry && o.geometry.dispose()); }
        const b = robotGeo.track_width, wr = robotGeo.wheel_radius;
        const R = Math.max(b * 0.36, 0.06), z0 = Math.max(0.02, wr * 0.6), zTop = z0 + 0.07 + R * 0.35;
        const body = new T.Group();
        const cyl = (r1, r2, h, seg, m, x, y, z) => {
            const mesh = new T.Mesh(new T.CylinderGeometry(r1, r2, h, seg), m);
            mesh.rotation.x = Math.PI / 2; mesh.position.set(x, y, z); mesh.castShadow = true; mesh.receiveShadow = true; return mesh;
        };
        body.add(cyl(R, R, zTop - z0, 32, mat(0x00bcd4, { metalness: 0.35, roughness: 0.35 }), 0, 0, (z0 + zTop) / 2));
        body.add(cyl(R * 0.82, R * 0.82, 0.012, 32, mat(0x1f2937), 0, 0, zTop + 0.006));
        body.add(cyl(R * 0.28, R * 0.28, 0.05, 20, new T.MeshStandardMaterial({ color: 0x111827, emissive: 0x7f1d1d }), -R * 0.12, 0, zTop + 0.037));
        const shp = new T.Shape(); shp.moveTo(R * 0.95, 0); shp.lineTo(R * 0.42, R * 0.3); shp.lineTo(R * 0.42, -R * 0.3);
        const arrow = new T.Mesh(new T.ShapeGeometry(shp), new T.MeshBasicMaterial({ color: 0xfacc15, side: T.DoubleSide }));
        arrow.position.z = zTop + 0.014; body.add(arrow);
        for (const sg of [-1, 1]) {
            const w = new T.Mesh(new T.CylinderGeometry(wr, wr, 0.04, 24), mat(0x2b2b35, { roughness: 0.9 }));
            w.position.set(0, sg * (b / 2 + 0.01), wr); w.castShadow = true;           // axis already along y
            const hub = new T.Mesh(new T.CylinderGeometry(wr * 0.45, wr * 0.45, 0.042, 12), mat(0x9ca3af));
            hub.position.copy(w.position); body.add(w, hub);
        }
        const caster = new T.Mesh(new T.SphereGeometry(0.02, 12, 8), mat(0x9ca3af)); caster.position.set(-R * 0.78, 0, 0.02); body.add(caster);
        robot = new T.Group(); robot.add(body); body.scale.setScalar(VIS);
        scene.add(robot); robotDirty = false;
    }

    // ---------- per-frame update ----------
    function setLine(line, pts, z) {
        const n = pts ? pts.length : 0, arr = new Float32Array(n * 3);
        for (let i = 0; i < n; i++) { arr[3 * i] = pts[i][0]; arr[3 * i + 1] = pts[i][1]; arr[3 * i + 2] = z; }
        line.geometry.dispose(); line.geometry = new T.BufferGeometry();
        line.geometry.setAttribute("position", new T.BufferAttribute(arr, 3));
        if (line.material.isLineDashedMaterial) line.computeLineDistances();
        line.visible = n > 1;
    }

    function updateObstacles(list) {
        while (obsPool.length < list.length) {
            const g = new T.Group();
            const body = new T.Mesh(new T.CylinderGeometry(1, 1, 0.7, 24), mat(0xdc3c3c, { roughness: 0.5 }));
            const cap = new T.Mesh(new T.CylinderGeometry(0.6, 0.6, 0.08, 16), new T.MeshStandardMaterial({ color: 0xffc846, emissive: 0x664400 }));
            body.rotation.x = Math.PI / 2; body.position.z = 0.35; cap.rotation.x = Math.PI / 2; cap.position.z = 0.74;
            body.castShadow = cap.castShadow = true;
            const arr = new T.ArrowHelper(new T.Vector3(1, 0, 0), new T.Vector3(0, 0, 0.9), 0.5, 0xffd600, 0.15, 0.1);
            g.add(body, cap, arr); g.userData = { body, cap, arr }; obsGroup.add(g); obsPool.push(g);
        }
        obsPool.forEach((g, i) => {
            const o = list[i]; g.visible = !!o; if (!o) return;
            g.position.set(o.pos[0], o.pos[1], 0);
            g.userData.body.scale.set(o.radius, 1, o.radius); g.userData.cap.scale.set(o.radius, 1, o.radius);
            const v = o.vel || [0, 0], sp = Math.hypot(v[0], v[1]);
            g.userData.arr.visible = sp > 0.01;
            if (sp > 0.01) { g.userData.arr.setDirection(new T.Vector3(v[0] / sp, v[1] / sp, 0)); g.userData.arr.setLength(Math.max(0.3, sp * 1.5), 0.15, 0.1); }
        });
    }

    function updateCamera(data) {
        if (cam.mode === "top") { cam.az = -Math.PI / 2; cam.el = 1.5; cam.dist = 15.5; cam.target.set(5, 5, 0); }
        else if (cam.mode === "chase" && data && data.pose) {
            cam.az += wrapPi(data.pose[2] + Math.PI - cam.az) * 0.18; cam.el = 0.42; cam.dist = 4.2;
            cam.target.set(data.pose[0], data.pose[1], 0.2);
        } else if (cam.mode === "orbit") cam.target.set(5, 5, 0);
        const ce = Math.cos(cam.el), se = Math.sin(cam.el);
        camera.position.set(cam.target.x + cam.dist * ce * Math.cos(cam.az), cam.target.y + cam.dist * ce * Math.sin(cam.az), cam.target.z + cam.dist * se);
        camera.lookAt(cam.target);
    }

    function render(data, startPt) {
        if (!renderer) return;
        if (data) last = data;
        if (startPt) lastStart = startPt;
        data = last;
        updateCamera(data);
        startRing.position.set(lastStart[0], lastStart[1], 0.012);
        if (data) {
            if (robotDirty || !robot) buildRobot();
            if (data.pose) { robot.position.set(data.pose[0], data.pose[1], 0); robot.rotation.z = data.pose[2]; }
            if (data.goal) { goalGroup.visible = true; goalGroup.position.set(data.goal[0], data.goal[1], 0); }
            updateObstacles(data.dynamic_obstacles || []);
            setLine(pathLine, data.global_path, 0.03);
            setLine(trailLine, data.trajectory, 0.04);
            if (data.lidar_ranges && data.pose) {
                const n = data.lidar_ranges.length, th = data.pose[2], a = new Float32Array(n * 6);
                for (let i = 0; i < n; i++) {
                    const ang = th + (-Math.PI + i * 2 * Math.PI / n), d = data.lidar_ranges[i];
                    a.set([data.pose[0], data.pose[1], 0.12, data.pose[0] + d * Math.cos(ang), data.pose[1] + d * Math.sin(ang), 0.12], i * 6);
                }
                lidarLines.geometry.dispose(); lidarLines.geometry = new T.BufferGeometry();
                lidarLines.geometry.setAttribute("position", new T.BufferAttribute(a, 3)); lidarLines.visible = true;
            } else lidarLines.visible = false;
        }
        renderer.render(scene, camera);
    }

    function setMode(m) {
        cam.mode = m;
        if (m === "orbit") { cam.az = -Math.PI / 2; cam.el = 0.62; cam.dist = 15.5; }
        render();
    }

    window.View3D = {
        init,
        setGrid: grid => { rects = buildRects(grid); rebuildStatic(); },
        setRobot: geo => { if (geo) { robotGeo = geo; robotDirty = true; } },
        render,
        remember: (d, st) => { last = d; if (st) lastStart = st; },
        redraw: () => render(),
        setMode,
        set onGroundClick(fn) { api.onGroundClick = fn; },
        get onGroundClick() { return api.onGroundClick; },
    };
})();
