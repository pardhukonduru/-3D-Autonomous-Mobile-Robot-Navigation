"""
Flask Web Application Server
Provides REST API endpoints for real-time simulation, canvas rendering, and benchmarking.
"""

import os
import sys

# Allow running this file directly (e.g. VS Code "Run Python File"): put the
# project root on the import path so `simulation`, `config`, etc. are found.
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


from flask import Flask, render_template, jsonify, request
import numpy as np
import secrets
from simulation.simulator import SimulationEngine
from simulation.benchmark import BenchmarkSuite

app = Flask(__name__, template_folder="templates", static_folder="static")

def _json_safe(value):
    """Recursively convert NumPy scalars/arrays into JSON-native values."""
    if isinstance(value, dict):
        return {str(k): _json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


@app.errorhandler(Exception)
def handle_server_error(exc):
    app.logger.exception("Simulation API error")
    return jsonify({"error": str(exc)}), 500

# Global simulation instance
sim_engine = SimulationEngine()

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/health")
def health():
    return jsonify({"status": "ok", "build": "FINAL-VERIFIED", "version": "2.0"})

@app.route("/api/init", methods=["POST"])
def api_init():
    global sim_engine
    data = request.json or {}
    robot_config = data.get("robot", "burger")
    global_planner = data.get("global_planner", "AStar")
    start = data.get("start", [1.0, 1.0])
    goal = data.get("goal", [9.0, 9.0])

    try:
        start = [float(start[0]), float(start[1])]
        goal = [float(goal[0]), float(goal[1])]
    except (TypeError, ValueError, IndexError):
        return jsonify({"error": "Start and goal must be [x, y] numbers in metres."}), 400

    new_engine = SimulationEngine(config_name=robot_config)
    # New randomized dynamic-obstacle scenario for every initialization/reset.
    # The browser does not send a seed, so secrets provides a fresh scenario.
    scenario_seed = int(data.get("scenario_seed", secrets.randbits(32)))
    new_engine.setup_default_map(scenario_seed=scenario_seed, start=tuple(start), goal=tuple(goal))

    # Validate the user-selected points before using them.
    for label, pt in (("Start", start), ("Goal", goal)):
        err = new_engine.validate_point(pt, label)
        if err:
            return jsonify({"error": err}), 400
    if np.hypot(goal[0] - start[0], goal[1] - start[1]) < 1.0:
        return jsonify({"error": "Start and goal must be at least 1 m apart."}), 400

    new_engine.set_start_and_goal((start[0], start[1]), (goal[0], goal[1]))
    path = new_engine.plan_global_path(global_planner)
    if not new_engine.path_is_safe:
        return jsonify({"error": "No collision-free path exists between these start and goal points."}), 400

    # Face the first waypoint when the user picked custom points (default keeps heading 0).
    if [start, goal] != [[1.0, 1.0], [9.0, 9.0]] and len(path) > 1:
        new_engine.pose[2] = float(np.arctan2(path[1][1] - start[1], path[1][0] - start[0]))
    sim_engine = new_engine

    lidar_ranges = sim_engine.lidar.scan(sim_engine.pose, sim_engine.grid, sim_engine.resolution, sim_engine.dynamic_obstacles)

    obs_dicts = [{"pos": obs.pos.tolist(), "radius": obs.radius, "vel": obs.vel.tolist()} for obs in sim_engine.dynamic_obstacles]

    return jsonify(_json_safe({
        "status": "initialized",
        "grid": sim_engine.grid.tolist(),
        "global_path": path,
        "planner_used": sim_engine.planner_used,
        "robot_geometry": {"name": sim_engine.config.name,
                           "track_width": sim_engine.config.track_width,
                           "wheel_radius": sim_engine.config.wheel_radius},
        "pose": sim_engine.pose.tolist(),
        "goal": sim_engine.goal.tolist(),
        "dynamic_obstacles": obs_dicts,
        "lidar_ranges": lidar_ranges.tolist()
    }))

@app.route("/api/step", methods=["POST"])
def api_step():
    global sim_engine
    data = request.json or {}
    dt = data.get("dt", 0.05)
    controller_mode = data.get("controller", "Adaptive_CTC")
    planner_mode = data.get("local_planner", "ANFIS_APF")
    speed_regulator = float(data.get("speed_regulator", 0.5))

    step_info = sim_engine.step(dt=dt, controller_mode=controller_mode, planner_mode=planner_mode, speed_regulator=speed_regulator)
    lidar_ranges = sim_engine.lidar.scan(sim_engine.pose, sim_engine.grid, sim_engine.resolution, sim_engine.dynamic_obstacles)

    obs_dicts = [{"pos": obs.pos.tolist(), "radius": obs.radius, "vel": obs.vel.tolist()} for obs in sim_engine.dynamic_obstacles]

    return jsonify(_json_safe({
        "pose": step_info["pose"],
        "v_vec": step_info["v_vec"],
        "torques": step_info["torques"],
        "sim_time": step_info["sim_time"],
        "done": step_info["done"],
        "collision": step_info["collision"],
        "adapted_params": step_info["adapted_params"],
        "grid": sim_engine.grid.tolist(),
        "global_path": sim_engine.global_path,
        "trajectory": sim_engine.trajectory_history,
        "goal": sim_engine.goal.tolist(),
        "dynamic_obstacles": obs_dicts,
        "lidar_ranges": lidar_ranges.tolist(),
        "telemetry": sim_engine.telemetry
    }))

@app.route("/api/benchmark", methods=["POST"])
def api_benchmark():
    suite = BenchmarkSuite(num_trials=20)
    results = suite.run_benchmarks()
    return jsonify(results)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5050, debug=False, threaded=True)
