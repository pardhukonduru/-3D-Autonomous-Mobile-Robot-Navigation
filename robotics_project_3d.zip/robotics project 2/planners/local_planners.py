"""
Local/Reactive Planners Module
Implements Artificial Potential Field (APF) and Dynamic Window Approach (DWA) for dynamic collision avoidance.
"""

import numpy as np

class ArtificialPotentialField:
    def __init__(
        self,
        k_att: float = 2.5,
        k_rep: float = 8.0,
        d_0: float = 1.5,
        robot_radius: float = 0.2
    ):
        self.k_att = k_att
        self.k_rep = k_rep
        self.d_0 = d_0
        self.robot_radius = robot_radius

    def compute_force(
        self,
        current_pos: np.ndarray,
        goal_pos: np.ndarray,
        obstacles: list[dict] # Each obstacle: {"pos": [x,y], "radius": r, "vel": [vx,vy]}
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        Computes net artificial force vector F_net = F_att + F_rep.
        Returns: (F_net, F_att, F_rep)
        """
        # Attractive force
        d_goal = np.linalg.norm(goal_pos - current_pos)
        if d_goal < 1e-4:
            F_att = np.zeros(2)
        else:
            F_att = self.k_att * (goal_pos - current_pos) / max(0.5, d_goal)

        # Repulsive force
        F_rep = np.zeros(2)
        for obs in obstacles:
            obs_pos = np.array(obs["pos"])
            obs_vel = np.array(obs.get("vel", [0.0, 0.0]))
            obs_radius = obs.get("radius", 0.3)

            # Predictive collision distance taking obstacle velocity into account
            rel_pos = current_pos - obs_pos
            dist_to_center = np.linalg.norm(rel_pos)
            dist_to_surface = max(0.01, dist_to_center - (obs_radius + self.robot_radius))

            d_0 = obs.get("d_0", self.d_0)
            if dist_to_surface <= d_0:
                # Direction pointing away from obstacle
                unit_vec = rel_pos / max(1e-5, dist_to_center)

                # Relative velocity boost for dynamic obstacles
                vel_boost = max(0.0, np.dot(obs_vel, unit_vec))

                # GNRON modified repulsive force formula
                rep_mag = self.k_rep * (1.0 / dist_to_surface - 1.0 / d_0) * (1.0 / (dist_to_surface ** 2)) * (1.0 + 0.5 * vel_boost)
                # Goal distance weighting to solve goal non-reachable issue
                goal_weight = min(1.0, d_goal)
                F_rep += rep_mag * goal_weight * unit_vec
                # Tangential (swirl) component: slides the robot around the
                # obstacle on the side facing the goal, escaping local minima
                # where attraction and repulsion cancel head-on.
                tang = np.array([-unit_vec[1], unit_vec[0]])
                if np.dot(tang, goal_pos - current_pos) < 0:
                    tang = -tang
                F_rep += 1.5 * rep_mag * goal_weight * tang

        F_net = F_att + F_rep
        return F_net, F_att, F_rep

    def compute_heading_and_speed(
        self,
        current_pose: np.ndarray,
        goal_pos: np.ndarray,
        obstacles: list[dict],
        max_v: float = 0.5,
        max_omega: float = 2.0
    ) -> tuple[float, float]:
        """
        Converts potential forces into desired linear and angular velocity (v_d, omega_d).
        """
        x, y, theta = current_pose[0], current_pose[1], current_pose[2]
        F_net, _, _ = self.compute_force(current_pose[:2], goal_pos, obstacles)

        target_angle = np.arctan2(F_net[1], F_net[0])
        angle_diff = (target_angle - theta + np.pi) % (2 * np.pi) - np.pi

        # Angular speed proportional to angle error
        omega_d = np.clip(2.0 * angle_diff, -max_omega, max_omega)

        # Scale down linear velocity if turning sharply or close to obstacles
        force_mag = np.linalg.norm(F_net)
        alignment = max(0.0, np.cos(angle_diff))
        # Keep some forward speed while turning away from a nearby obstacle;
        # creeping at near-zero speed lets moving obstacles catch the robot.
        rep_dominant = np.linalg.norm(F_net - (goal_pos - current_pose[:2]) / max(0.5, np.linalg.norm(goal_pos - current_pose[:2]))) > 1.5
        if rep_dominant:
            alignment = max(alignment, 0.35)
        v_d = max_v * alignment * min(1.0, force_mag / 2.0)

        return float(v_d), float(omega_d)


class DynamicWindowApproach:
    """Dynamic Window Approach (DWA) Local Planner."""
    def __init__(self, robot_radius: float = 0.2, dt: float = 0.1, predict_time: float = 1.5):
        self.robot_radius = robot_radius
        self.dt = dt
        self.predict_time = predict_time

    def plan(
        self,
        pose: np.ndarray,
        v_current: float,
        w_current: float,
        goal: np.ndarray,
        obstacles: list[dict],
        max_v: float = 0.5,
        max_w: float = 2.0,
        max_v_dot: float = 0.8,
        max_w_dot: float = 3.0,
        static_grid: np.ndarray | None = None,
        resolution: float = 0.1
    ) -> tuple[float, float]:
        """Samples velocity space (v, w) within dynamic window and picks trajectory with max objective score."""
        # Dynamic window search bounds
        v_min = max(0.0, v_current - max_v_dot * self.dt)
        v_max = min(max_v, v_current + max_v_dot * self.dt)
        w_min = max(-max_w, w_current - max_w_dot * self.dt)
        w_max = min(max_w, w_current + max_w_dot * self.dt)

        v_samples = np.linspace(v_min, v_max, 4)
        w_samples = np.linspace(w_min, w_max, 5)

        best_score = -1e9
        best_v, best_w = 0.0, 0.0

        for v in v_samples:
            for w in w_samples:
                # Predict trajectory
                traj = self.predict_trajectory(pose, v, w)

                # Compute scores
                heading_score = self.calc_heading_score(traj[-1], goal)
                clearance_score = self.calc_clearance_score(traj, obstacles, static_grid, resolution)
                velocity_score = v / max_v

                if clearance_score < 0.1: # Collision
                    continue

                total_score = 0.4 * heading_score + 0.4 * clearance_score + 0.2 * velocity_score
                if total_score > best_score:
                    best_score = total_score
                    best_v, best_w = v, w

        return float(best_v), float(best_w)

    def predict_trajectory(self, pose: np.ndarray, v: float, w: float) -> list[np.ndarray]:
        steps = int(self.predict_time / self.dt)
        traj = [pose.copy()]
        curr = pose.copy()
        for _ in range(steps):
            curr[0] += v * np.cos(curr[2]) * self.dt
            curr[1] += v * np.sin(curr[2]) * self.dt
            curr[2] += w * self.dt
            traj.append(curr.copy())
        return traj

    def calc_heading_score(self, final_pose: np.ndarray, goal: np.ndarray) -> float:
        angle_to_goal = np.arctan2(goal[1] - final_pose[1], goal[0] - final_pose[0])
        diff = abs((angle_to_goal - final_pose[2] + np.pi) % (2 * np.pi) - np.pi)
        return float(np.cos(diff))

    def calc_clearance_score(self, traj: list[np.ndarray], obstacles: list[dict], static_grid=None, resolution: float = 0.1) -> float:
        min_dist = 10.0
        for pt in traj:
            for obs in obstacles:
                d = np.linalg.norm(pt[:2] - np.array(obs["pos"])) - (obs.get("radius", 0.3) + self.robot_radius)
                min_dist = min(min_dist, d)
            if static_grid is not None:
                r = int(round(pt[1] / resolution))
                c = int(round(pt[0] / resolution))
                if r < 0 or c < 0 or r >= static_grid.shape[0] or c >= static_grid.shape[1]:
                    return 0.0
                if static_grid[r, c] == 1:
                    return 0.0
        return float(np.clip(min_dist, 0.0, 3.0) / 3.0)
