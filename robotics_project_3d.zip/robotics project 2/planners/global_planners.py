"""
Global Path Planners Module
Implements A* (Grid Search), RRT* (Optimal Sampling-based), and Genetic Algorithm (GA).
"""

import numpy as np
import heapq
import random

class AStarPlanner:
    def __init__(self, grid: np.ndarray, resolution: float = 0.1, robot_radius: float = 0.2):
        """
        grid: 2D numpy array where 0 = free, 1 = obstacle
        resolution: meters per cell
        """
        self.resolution = resolution
        self.robot_radius = robot_radius
        self.inflation_cells = int(np.ceil(robot_radius / resolution))
        self.inflate_grid(grid)

    def inflate_grid(self, raw_grid: np.ndarray):
        """Inflates static obstacles by robot radius to guarantee collision clearance."""
        self.grid = raw_grid.copy()
        rows, cols = raw_grid.shape
        obs_indices = np.argwhere(raw_grid > 0)
        for r, c in obs_indices:
            r_min = max(0, r - self.inflation_cells)
            r_max = min(rows, r + self.inflation_cells + 1)
            c_min = max(0, c - self.inflation_cells)
            c_max = min(cols, c + self.inflation_cells + 1)
            self.grid[r_min:r_max, c_min:c_max] = 1

    def world_to_grid(self, point: tuple[float, float]) -> tuple[int, int]:
        r = int(round(point[1] / self.resolution))
        c = int(round(point[0] / self.resolution))
        rows, cols = self.grid.shape
        r = np.clip(r, 0, rows - 1)
        c = np.clip(c, 0, cols - 1)
        return int(r), int(c)

    def grid_to_world(self, cell: tuple[int, int]) -> tuple[float, float]:
        x = cell[1] * self.resolution
        y = cell[0] * self.resolution
        return float(x), float(y)

    def plan(self, start: tuple[float, float], goal: tuple[float, float]) -> list[tuple[float, float]]:
        start_cell = self.world_to_grid(start)
        goal_cell = self.world_to_grid(goal)

        if self.grid[start_cell] == 1 or self.grid[goal_cell] == 1:
            # Fallback if inside inflated region
            pass

        rows, cols = self.grid.shape
        open_set = []
        heapq.heappush(open_set, (0.0, start_cell))

        came_from = {}
        g_score = {start_cell: 0.0}

        def heuristic(a, b):
            return np.hypot(a[0] - b[0], a[1] - b[1])

        # 8-connected movement directions
        directions = [
            (0, 1, 1.0), (1, 0, 1.0), (0, -1, 1.0), (-1, 0, 1.0),
            (1, 1, 1.414), (1, -1, 1.414), (-1, 1, 1.414), (-1, -1, 1.414)
        ]

        found = False
        while open_set:
            _, current = heapq.heappop(open_set)

            if current == goal_cell:
                found = True
                break

            for dr, dc, cost in directions:
                neighbor = (current[0] + dr, current[1] + dc)

                if 0 <= neighbor[0] < rows and 0 <= neighbor[1] < cols:
                    if self.grid[neighbor] == 1:
                        continue

                    tentative_g = g_score[current] + cost
                    if neighbor not in g_score or tentative_g < g_score[neighbor]:
                        came_from[neighbor] = current
                        g_score[neighbor] = tentative_g
                        f_score = tentative_g + heuristic(neighbor, goal_cell)
                        heapq.heappush(open_set, (f_score, neighbor))

        if not found:
            return [start, goal]

        # Reconstruct path
        path_cells = [goal_cell]
        curr = goal_cell
        while curr in came_from:
            curr = came_from[curr]
            path_cells.append(curr)
        path_cells.reverse()

        path_world = [self.grid_to_world(c) for c in path_cells]
        return self.smooth_path(path_world)

    def smooth_path(self, path: list[tuple[float, float]]) -> list[tuple[float, float]]:
        """Path shortcutting to eliminate grid jaggedness."""
        if len(path) <= 2:
            return path
        smoothed = [path[0]]
        i = 0
        while i < len(path) - 1:
            j = len(path) - 1
            while j > i + 1:
                if self.is_line_collision_free(path[i], path[j]):
                    break
                j -= 1
            smoothed.append(path[j])
            i = j
        return smoothed

    def count_line_collisions(self, p1, p2) -> int:
        """Number of sample points along p1->p2 that fall in occupied (inflated) cells."""
        dist = float(np.hypot(p2[0] - p1[0], p2[1] - p1[1]))
        steps = max(1, int(np.ceil(dist / max(self.resolution, 0.10))))
        t = np.linspace(0.0, 1.0, steps + 1)
        xs = p1[0] + t * (p2[0] - p1[0])
        ys = p1[1] + t * (p2[1] - p1[1])
        rows, cols = self.grid.shape
        r = np.clip(np.rint(ys / self.resolution).astype(int), 0, rows - 1)
        c = np.clip(np.rint(xs / self.resolution).astype(int), 0, cols - 1)
        return int(np.count_nonzero(self.grid[r, c] == 1))

    def is_line_collision_free(self, p1: tuple[float, float], p2: tuple[float, float]) -> bool:
        return self.count_line_collisions(p1, p2) == 0


class RRTStarPlanner:
    """RRT* (Karaman & Frazzoli): steer, choose-best-parent, rewire with cost
    propagation, and continued refinement after the first solution is found."""

    class Node:
        def __init__(self, x: float, y: float):
            self.x = x
            self.y = y
            self.cost = 0.0
            self.parent = None
            self.children = []

    def __init__(
        self,
        grid: np.ndarray,
        resolution: float = 0.1,
        robot_radius: float = 0.2,
        step_size: float = 0.6,
        search_radius: float = 1.5,
        max_iter: int = 1500,
        refine_iter: int = 300,
        seed: int | None = None,
    ):
        self.grid = grid
        self.resolution = resolution
        self.robot_radius = robot_radius
        self.step_size = step_size
        self.search_radius = search_radius
        self.max_iter = max_iter
        self.refine_iter = refine_iter
        self.height, self.width = grid.shape[0] * resolution, grid.shape[1] * resolution
        self.astar_helper = AStarPlanner(grid, resolution, robot_radius)
        self.rng = random.Random(seed)
        self.used_fallback = False

    @staticmethod
    def _d(a, b) -> float:
        return float(np.hypot(a.x - b.x, a.y - b.y))

    def _propagate_cost(self, node, delta: float):
        stack = list(node.children)
        while stack:
            n = stack.pop()
            n.cost += delta
            stack.extend(n.children)

    def plan(self, start: tuple[float, float], goal: tuple[float, float]) -> list[tuple[float, float]]:
        free = self.astar_helper.is_line_collision_free
        start_node = self.Node(float(start[0]), float(start[1]))
        goal_node = self.Node(float(goal[0]), float(goal[1]))
        nodes = [start_node]
        best_goal_parent, best_goal_cost = None, float("inf")
        iters_after_solution = 0
        self.used_fallback = False

        for _ in range(self.max_iter):
            if best_goal_parent is not None:
                iters_after_solution += 1
                if iters_after_solution > self.refine_iter:
                    break

            rand_pt = goal_node if self.rng.random() < 0.10 else self.Node(
                self.rng.uniform(0, self.width), self.rng.uniform(0, self.height))
            nearest = min(nodes, key=lambda n: self._d(n, rand_pt))
            dist = self._d(nearest, rand_pt)
            if dist < 1e-9:
                continue
            step = min(self.step_size, dist)  # never overshoot the sample
            new_x = nearest.x + step * (rand_pt.x - nearest.x) / dist
            new_y = nearest.y + step * (rand_pt.y - nearest.y) / dist
            if not free((nearest.x, nearest.y), (new_x, new_y)):
                continue

            new_node = self.Node(new_x, new_y)
            near_nodes = [n for n in nodes
                          if self._d(n, new_node) <= self.search_radius
                          and free((n.x, n.y), (new_x, new_y))]

            # Choose best parent
            new_node.parent = nearest
            new_node.cost = nearest.cost + self._d(nearest, new_node)
            for near in near_nodes:
                c = near.cost + self._d(near, new_node)
                if c < new_node.cost:
                    new_node.cost, new_node.parent = c, near
            new_node.parent.children.append(new_node)
            nodes.append(new_node)

            # Rewire neighbours through the new node (propagating cost to descendants)
            for near in near_nodes:
                if near is new_node.parent or near is start_node:
                    continue
                c = new_node.cost + self._d(near, new_node)
                if c < near.cost - 1e-9:
                    delta = c - near.cost
                    near.parent.children.remove(near)
                    near.parent = new_node
                    new_node.children.append(near)
                    near.cost = c
                    self._propagate_cost(near, delta)

            # Try to connect to the goal
            dg = self._d(new_node, goal_node)
            if dg <= self.step_size * 2.0 and new_node.cost + dg < best_goal_cost \
                    and free((new_node.x, new_node.y), (goal_node.x, goal_node.y)):
                best_goal_parent, best_goal_cost = new_node, new_node.cost + dg

        if best_goal_parent is None:
            self.used_fallback = True
            return self.astar_helper.plan(start, goal)

        path = [(goal_node.x, goal_node.y)]
        curr = best_goal_parent
        while curr:
            path.append((curr.x, curr.y))
            curr = curr.parent
        path.reverse()
        return self.astar_helper.smooth_path(path)


class GeneticPlanner:
    """Genetic Algorithm global path optimiser (paper Sec. 2.2.3, Algorithm 1):
    population init -> fitness (path length + collision penalty) -> tournament
    selection -> one-point crossover -> mutation -> elitism, repeated for G generations."""

    def __init__(
        self,
        grid: np.ndarray,
        resolution: float = 0.1,
        robot_radius: float = 0.2,
        pop_size: int = 60,
        num_waypoints: int = 5,
        max_gen: int = 70,
        mutation_rate: float = 0.35,
        seed: int | None = None,
    ):
        self.grid = grid
        self.resolution = resolution
        self.pop_size = pop_size
        self.num_waypoints = num_waypoints
        self.max_gen = max_gen
        self.mutation_rate = mutation_rate
        self.astar_helper = AStarPlanner(grid, resolution, robot_radius)
        self.width = grid.shape[1] * resolution
        self.height = grid.shape[0] * resolution
        self.rng = random.Random(seed)
        self.used_fallback = False

    def _rand_chrom(self, start, goal, wide: bool):
        pts = []
        for _ in range(self.num_waypoints):
            if wide:   # global exploration of the whole map
                pts.append((self.rng.uniform(0.3, self.width - 0.3), self.rng.uniform(0.3, self.height - 0.3)))
            else:      # local exploration around the straight start-goal line
                a = self.rng.random()
                pts.append((float(np.clip(start[0] + a * (goal[0] - start[0]) + self.rng.uniform(-1.5, 1.5), 0.3, self.width - 0.3)),
                            float(np.clip(start[1] + a * (goal[1] - start[1]) + self.rng.uniform(-1.5, 1.5), 0.3, self.height - 0.3))))
        # Order waypoints along the start->goal direction (keeps chromosomes meaningful)
        d = np.array(goal, float) - np.array(start, float)
        pts.sort(key=lambda p: float(np.dot(np.array(p) - np.array(start), d)))
        return pts

    def _fitness(self, chrom, start, goal) -> float:
        path = [start] + chrom + [goal]
        length, hits = 0.0, 0
        for a, b in zip(path[:-1], path[1:]):
            length += float(np.hypot(b[0] - a[0], b[1] - a[1]))
            hits += self.astar_helper.count_line_collisions(a, b)
        return length + 8.0 * hits   # lower is better

    def plan(self, start: tuple[float, float], goal: tuple[float, float]) -> list[tuple[float, float]]:
        start = (float(start[0]), float(start[1]))
        goal = (float(goal[0]), float(goal[1]))
        self.used_fallback = False
        pop = [self._rand_chrom(start, goal, wide=(i % 2 == 0)) for i in range(self.pop_size)]
        scored = sorted(((self._fitness(c, start, goal), c) for c in pop), key=lambda t: t[0])

        def tournament():
            cand = self.rng.sample(scored, 3)
            return min(cand, key=lambda t: t[0])[1]

        for _ in range(self.max_gen):
            elite = [c for _, c in scored[:4]]                 # elitism
            children = [list(c) for c in elite]
            while len(children) < self.pop_size:
                p1, p2 = tournament(), tournament()
                cut = self.rng.randint(1, self.num_waypoints - 1)   # one-point crossover
                child = list(p1[:cut]) + list(p2[cut:])
                if self.rng.random() < self.mutation_rate:          # mutation
                    i = self.rng.randrange(self.num_waypoints)
                    sig = self.rng.choice([0.2, 0.6, 1.5])
                    child[i] = (float(np.clip(child[i][0] + self.rng.gauss(0, sig), 0.3, self.width - 0.3)),
                                float(np.clip(child[i][1] + self.rng.gauss(0, sig), 0.3, self.height - 0.3)))
                children.append(child)
            scored = sorted(((self._fitness(c, start, goal), c) for c in children), key=lambda t: t[0])

        best = scored[0][1]
        path = [start] + best + [goal]
        if any(not self.astar_helper.is_line_collision_free(a, b) for a, b in zip(path[:-1], path[1:])):
            self.used_fallback = True            # GA did not converge to a feasible path
            return self.astar_helper.plan(start, goal)
        return self.astar_helper.smooth_path(path)
