"""
Intelligent Adaptation Layer (ANFIS / Heuristic Neuro-Fuzzy Parameter Adaptation)
Dynamically adapts local planner parameters (APF gains k_att, k_rep, influence distance d_0, speed scale)
in real time based on dynamic environment clutter, obstacle velocity threats, and passage narrowness.
"""

import numpy as np

class IntelligentAdaptationLayer:
    def __init__(self, sensing_radius: float = 3.0):
        self.sensing_radius = sensing_radius

    def extract_environment_features(
        self,
        robot_pose: np.ndarray,
        obstacles: list[dict],
        goal_pos: np.ndarray
    ) -> dict:
        """
        Calculates environment metrics:
        1. Clutter Density D_obs (0.0 to 1.0)
        2. Dynamic Threat Velocity V_threat (m/s)
        3. Passage Narrowness N_pass (0.0 to 1.0)
        """
        current_pos = robot_pose[:2]
        nearby_obs = []
        max_threat_vel = 0.0

        for obs in obstacles:
            obs_pos = np.array(obs["pos"])
            dist = np.linalg.norm(current_pos - obs_pos)
            if dist <= self.sensing_radius:
                nearby_obs.append(obs)
                obs_vel = np.array(obs.get("vel", [0.0, 0.0]))
                rel_vel = np.linalg.norm(obs_vel)
                if rel_vel > max_threat_vel:
                    max_threat_vel = rel_vel

        # 1. Clutter Density
        clutter_density = min(1.0, len(nearby_obs) / 8.0)

        # 2. Passage Narrowness (detect pairs of obstacles close to each other)
        passage_narrowness = 0.0
        if len(nearby_obs) >= 2:
            min_inter_dist = 10.0
            for i in range(len(nearby_obs)):
                for j in range(i + 1, len(nearby_obs)):
                    d = np.linalg.norm(np.array(nearby_obs[i]["pos"]) - np.array(nearby_obs[j]["pos"]))
                    min_inter_dist = min(min_inter_dist, d)
            if min_inter_dist < 1.2:
                passage_narrowness = float(np.clip((1.2 - min_inter_dist) / 1.0, 0.0, 1.0))

        return {
            "clutter_density": float(clutter_density),
            "max_threat_vel": float(max_threat_vel),
            "passage_narrowness": float(passage_narrowness),
            "num_nearby": int(len(nearby_obs))
        }

    def adapt_parameters(
        self,
        features: dict,
        base_k_att: float = 2.5,
        base_k_rep: float = 8.0,
        base_d_0: float = 1.5,
        base_v_max: float = 0.5
    ) -> dict:
        """
        ANFIS / Fuzzy Adaptive Rules:
        - High Clutter -> Increase k_rep, increase d_0, decrease v_max (safety priority)
        - High Dynamic Threat -> Increase k_rep significantly, increase d_0
        - High Passage Narrowness -> Reduce k_rep slightly (prevent repulsion oscillations in narrow door), lower speed
        - Open Space -> High v_max, baseline k_rep
        """
        clutter = features["clutter_density"]
        threat = features["max_threat_vel"]
        narrow = features["passage_narrowness"]

        # Membership evaluations
        is_crowded = clutter > 0.4
        is_threatening = threat > 0.2
        is_narrow_passage = narrow > 0.3

        k_att = base_k_att
        k_rep = base_k_rep
        d_0 = base_d_0
        v_max = base_v_max

        # Rule 1: High dynamic threat -> Boost repulsion distance and gain
        if is_threatening:
            k_rep *= (1.0 + 1.5 * threat)
            d_0 *= (1.0 + 0.5 * threat)

        # Rule 2: Narrow passage -> Avoid oscillation, increase attractive pull & reduce speed
        if is_narrow_passage:
            k_rep *= 0.6
            k_att *= 1.4
            v_max *= 0.6
        elif is_crowded:
            k_rep *= 1.3
            v_max *= 0.7

        return {
            "k_att": k_att,
            "k_rep": k_rep,
            "d_0": d_0,
            "v_max": v_max,
            "adaptation_active": bool(is_threatening or is_narrow_passage or is_crowded)
        }
