"""
Lagrangian Dynamics and Newton-Euler Verification Module
Defines the dynamic equations of motion: M(q)*v_dot + C(v)*v + F(v) = B(q)*tau
and verifies equivalence against Newton-Euler rigid body equations.
"""

import numpy as np
from config.robot_configs import RobotConfig, TURTLEBOT3_BURGER

class DifferentialDriveDynamics:
    def __init__(self, config: RobotConfig = TURTLEBOT3_BURGER):
        self.config = config
        self.m = config.mass
        self.I = config.inertia
        self.r = config.wheel_radius
        self.b = config.track_width
        self.m_w = config.wheel_mass
        self.I_w = config.wheel_inertia
        self.B_v = config.viscous_friction
        self.F_c = config.coulomb_friction
        self.max_tau = config.max_torque

        # Precompute reduced mass matrix components
        # M_11 = m + 2 * I_w / r^2
        # M_22 = I + (b^2 * I_w) / (2 * r^2)
        self.M_11 = self.m + (2.0 * self.I_w) / (self.r ** 2)
        self.M_22 = self.I + (self.b ** 2 * self.I_w) / (2.0 * self.r ** 2)

    def get_mass_matrix(self) -> np.ndarray:
        """Returns 2x2 reduced mass/inertia matrix M."""
        return np.array([
            [self.M_11, 0.0],
            [0.0, self.M_22]
        ])

    def get_input_matrix(self) -> np.ndarray:
        """
        Returns 2x2 matrix B mapping wheel torques [tau_l, tau_r]^T to generalized body forces [F_v, Torque_omega]^T.
        B = [ [1/r, 1/r], [-b/(2*r), b/(2*r)] ]
        """
        return np.array([
            [1.0 / self.r, 1.0 / self.r],
            [-self.b / (2.0 * self.r), self.b / (2.0 * self.r)]
        ])

    def get_coriolis_matrix(self, v_vec: np.ndarray) -> np.ndarray:
        """
        Coriolis matrix C(v). For planar differential drive with center of mass at drive axle,
        C(v) = 0 in body coordinates, but non-zero if CoM is offset by d.
        Assuming centered CoM here (C = 0 matrix).
        """
        return np.zeros((2, 2))

    def get_friction_vector(self, v_vec: np.ndarray) -> np.ndarray:
        """
        Computes viscous + Coulomb friction force vector F(v, omega).
        F = [ B_v * v + F_c * tanh(10 * v), B_v * omega + F_c * tanh(10 * omega) ]
        """
        v, omega = v_vec[0], v_vec[1]
        f_v = self.B_v * v + self.F_c * np.tanh(10.0 * v)
        f_w = self.B_v * omega + self.F_c * np.tanh(10.0 * omega)
        return np.array([f_v, f_w])

    def forward_dynamics(self, v_vec: np.ndarray, tau: np.ndarray) -> np.ndarray:
        """
        Computes linear and angular accelerations v_dot = [dv/dt, domega/dt]^T
        from current velocities v_vec and wheel torques tau = [tau_l, tau_r]^T.
        M * v_dot = B * tau - C*v - F(v)
        => v_dot = M^-1 * (B * tau - F(v))
        """
        # Apply motor torque saturation
        tau_sat = np.clip(tau, -self.max_tau, self.max_tau)

        M = self.get_mass_matrix()
        B = self.get_input_matrix()
        F = self.get_friction_vector(v_vec)

        net_force = B @ tau_sat - F
        v_dot = np.linalg.solve(M, net_force)
        return v_dot

    def inverse_dynamics(self, v_vec: np.ndarray, v_dot_desired: np.ndarray) -> np.ndarray:
        """
        Computed torque control step: calculates required wheel torques tau = [tau_l, tau_r]^T
        to achieve desired acceleration v_dot_desired given velocity v_vec.
        tau = B^+ * (M * v_dot_desired + F(v))
        """
        M = self.get_mass_matrix()
        B = self.get_input_matrix()
        F = self.get_friction_vector(v_vec)

        required_generalized_force = M @ v_dot_desired + F
        # B_inv = B inverse:
        # B = [[1/r, 1/r], [-b/(2r), b/(2r)]] => det = b/r^2
        # B_inv = r/2 * [[1, -2/b], [1, 2/b]]
        B_inv = (self.r / 2.0) * np.array([
            [1.0, -2.0 / self.b],
            [1.0, 2.0 / self.b]
        ])

        tau = B_inv @ required_generalized_force
        return np.clip(tau, -self.max_tau, self.max_tau)

    def newton_euler_cross_check(self, v_vec: np.ndarray, tau: np.ndarray) -> dict:
        """
        Independently computes acceleration via Newton-Euler rigid body free-body diagram:
        1. Traction forces: F_left = tau_l / r, F_right = tau_r / r
        2. Sum of linear forces: F_net = F_left + F_right - F_friction_linear
        3. dv/dt = F_net / M_effective_linear
        4. Sum of moments about CoM: Torque_net = (F_right - F_left) * (b/2) - F_friction_rotational
        5. domega/dt = Torque_net / I_effective_rotational
        Returns comparison dict against Lagrangian derivation.
        """
        tau_sat = np.clip(tau, -self.max_tau, self.max_tau)
        F_l = tau_sat[0] / self.r
        F_r = tau_sat[1] / self.r

        F_fric = self.get_friction_vector(v_vec)

        # Newton-Euler linear equation: (F_l + F_r) - F_fric[0] = M_11 * dv_dt
        dv_dt_ne = (F_l + F_r - F_fric[0]) / self.M_11

        # Newton-Euler angular equation: (F_r - F_l) * (b/2) - F_fric[1] = M_22 * domega_dt
        domega_dt_ne = ((F_r - F_l) * (self.b / 2.0) - F_fric[1]) / self.M_22

        v_dot_lagrange = self.forward_dynamics(v_vec, tau)

        error_v = abs(dv_dt_ne - v_dot_lagrange[0])
        error_w = abs(domega_dt_ne - v_dot_lagrange[1])

        return {
            "v_dot_lagrange": v_dot_lagrange,
            "v_dot_newton_euler": np.array([dv_dt_ne, domega_dt_ne]),
            "max_abs_error": max(error_v, error_w),
            "match": max(error_v, error_w) < 1e-12
        }
