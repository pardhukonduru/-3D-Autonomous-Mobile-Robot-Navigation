"""
Kinematic Model of Differential-Drive Autonomous Mobile Robot
Implements forward/inverse kinematics, transformation matrices, and RK4 integrator.
"""

import numpy as np
from config.robot_configs import RobotConfig, TURTLEBOT3_BURGER

class DifferentialDriveKinematics:
    def __init__(self, config: RobotConfig = TURTLEBOT3_BURGER):
        self.config = config
        self.r = config.wheel_radius
        self.b = config.track_width

    def wheel_to_robot_velocities(self, omega_l: float, omega_r: float) -> tuple[float, float]:
        """
        Converts left and right wheel angular velocities (rad/s) to body linear v (m/s) and angular omega (rad/s).
        Eq. 7-8 from Loganathan & Ahmad (2023):
        v = (r / 2) * (omega_r + omega_l)
        omega = (r / b) * (omega_r - omega_l)
        """
        v = (self.r / 2.0) * (omega_r + omega_l)
        omega = (self.r / self.b) * (omega_r - omega_l)
        return v, omega

    def robot_to_wheel_velocities(self, v: float, omega: float) -> tuple[float, float]:
        """
        Converts body linear velocity v and angular velocity omega to left and right wheel angular velocities.
        omega_l = (v - (b/2)*omega) / r
        omega_r = (v + (b/2)*omega) / r
        """
        omega_l = (v - (self.b / 2.0) * omega) / self.r
        omega_r = (v + (self.b / 2.0) * omega) / self.r
        return omega_l, omega_r

    def pose_derivatives(self, state: np.ndarray, v: float, omega: float) -> np.ndarray:
        """
        State: [x, y, theta]
        Returns: [dx/dt, dy/dt, dtheta/dt]
        dx = v * cos(theta)
        dy = v * sin(theta)
        dtheta = omega
        """
        theta = state[2]
        dx = v * np.cos(theta)
        dy = v * np.sin(theta)
        dtheta = omega
        return np.array([dx, dy, dtheta])

    def euler_step(self, pose: np.ndarray, v: float, omega: float, dt: float) -> np.ndarray:
        """Forward Euler integration step."""
        dpose = self.pose_derivatives(pose, v, omega)
        new_pose = pose + dpose * dt
        new_pose[2] = self.normalize_angle(new_pose[2])
        return new_pose

    def rk4_step(self, pose: np.ndarray, v: float, omega: float, dt: float) -> np.ndarray:
        """4th-Order Runge-Kutta (RK4) integration for high precision kinematic update."""
        k1 = self.pose_derivatives(pose, v, omega)
        k2 = self.pose_derivatives(pose + 0.5 * dt * k1, v, omega)
        k3 = self.pose_derivatives(pose + 0.5 * dt * k2, v, omega)
        k4 = self.pose_derivatives(pose + dt * k3, v, omega)

        new_pose = pose + (dt / 6.0) * (k1 + 2.0 * k2 + 2.0 * k3 + k4)
        new_pose[2] = self.normalize_angle(new_pose[2])
        return new_pose

    @staticmethod
    def normalize_angle(angle: float) -> float:
        """Wraps angle to [-pi, pi]."""
        return (angle + np.pi) % (2 * np.pi) - np.pi
