"""
Symbolic Proof Verifier using SymPy
Derives Euler-Lagrange equations of motion and proves exact identity with Newton-Euler equations.
"""

import sympy as sp

def verify_symbolic_dynamics():
    """
    Symbolically derives Euler-Lagrange equations for non-holonomic differential-drive AMR
    and proves equality with Newton-Euler formulation.
    """
    # Define symbols
    t = sp.Symbol('t')
    m, I, r, b, I_w = sp.symbols('m I r b I_w', positive=True, real=True)
    v = sp.Function('v')(t)
    omega = sp.Function('omega')(t)
    theta = sp.Function('theta')(t)
    tau_l, tau_r = sp.symbols('tau_l tau_r', real=True)

    # State derivatives
    v_dot = sp.diff(v, t)
    omega_dot = sp.diff(omega, t)

    # Wheel angular velocities in terms of (v, omega)
    omega_l = (v - (b / 2) * omega) / r
    omega_r = (v + (b / 2) * omega) / r

    # Kinetic Energy T
    # T_body_trans = 0.5 * m * v^2
    # T_body_rot   = 0.5 * I * omega^2
    # T_wheels_rot = 0.5 * I_w * omega_l^2 + 0.5 * I_w * omega_r^2
    T_trans = sp.Rational(1, 2) * m * v**2
    T_rot = sp.Rational(1, 2) * I * omega**2
    T_wheels = sp.Rational(1, 2) * I_w * (omega_l**2 + omega_r**2)

    T_total = sp.simplify(T_trans + T_rot + T_wheels)

    # Generalized forces from wheel torques (virtual work dW = tau_l dphi_l + tau_r dphi_r)
    # F_v = (tau_l + tau_r) / r
    # Torque_omega = (tau_r - tau_l) * (b / (2 * r))
    F_v_input = (tau_l + tau_r) / r
    Torque_omega_input = (tau_r - tau_l) * (b / (2 * r))

    # Euler-Lagrange equations for reduced coordinates (v, omega):
    # d/dt (dT/dv_dot) - dT/dv -> Since T is expressed in v and omega,
    # d/dt (dT/dv) = M_11 * v_dot
    # d/dt (dT/domega) = M_22 * omega_dot

    dT_dv = sp.diff(T_total, v)
    dT_domega = sp.diff(T_total, omega)

    eq_v_lagrange = sp.simplify(sp.diff(dT_dv, t))
    eq_omega_lagrange = sp.simplify(sp.diff(dT_domega, t))

    # Newton-Euler Equations from Free Body Diagram:
    # Wheel traction forces: F_left = tau_l / r, F_right = tau_r / r
    # Effective linear inertia: M_eff = m + 2 * I_w / r^2
    # Effective rotational inertia: I_eff = I + (b^2 * I_w) / (2 * r^2)

    M_eff = m + 2 * I_w / r**2
    I_eff = I + (b**2 * I_w) / (2 * r**2)

    eq_v_ne = M_eff * v_dot
    eq_omega_ne = I_eff * omega_dot

    # Proof of equivalence
    v_diff = sp.simplify(eq_v_lagrange - eq_v_ne)
    omega_diff = sp.simplify(eq_omega_lagrange - eq_omega_ne)

    match_v = (v_diff == 0)
    match_omega = (omega_diff == 0)

    proof_results = {
        "Kinetic_Energy": str(T_total),
        "Lagrange_v_lhs": str(eq_v_lagrange),
        "Newton_Euler_v_lhs": str(eq_v_ne),
        "Lagrange_omega_lhs": str(eq_omega_lagrange),
        "Newton_Euler_omega_lhs": str(eq_omega_ne),
        "v_equation_match": match_v,
        "omega_equation_match": match_omega,
        "overall_symbolic_proof": match_v and match_omega
    }

    return proof_results

if __name__ == "__main__":
    res = verify_symbolic_dynamics()
    print("--- SYMBOLIC DYNAMICS VERIFICATION ---")
    for k, val in res.items():
        print(f"{k}: {val}")
