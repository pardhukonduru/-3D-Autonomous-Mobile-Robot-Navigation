import os
import sys

# Allow running this file directly (e.g. VS Code "Run Python File"): put the
# project root on the import path so `simulation`, `config`, etc. are found.
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import itertools
import unittest
import numpy as np
from simulation.simulator import SimulationEngine

class TestFullExecution(unittest.TestCase):
    def test_global_planners_use_their_own_algorithm_and_end_at_goal(self):
        # RRT* and GA must produce their own safe path (no silent A* fallback).
        for planner in ["AStar", "RRTStar", "Genetic"]:
            for seed in (0, 1, 2):
                with self.subTest(planner=planner, seed=seed):
                    sim = SimulationEngine("burger")
                    sim.setup_default_map(scenario_seed=seed)
                    sim.set_start_and_goal((1.0, 1.0), (9.0, 9.0))
                    path = sim.plan_global_path(planner)
                    self.assertNotIn("fallback", sim.planner_used)
                    self.assertAlmostEqual(path[-1][0], 9.0)
                    self.assertAlmostEqual(path[-1][1], 9.0)

    def test_every_global_planner_reaches_goal(self):
        for planner in ["AStar", "RRTStar", "Genetic"]:
            for seed in (0, 1, 2):
                with self.subTest(planner=planner, seed=seed):
                    sim = SimulationEngine("burger")
                    sim.setup_default_map(scenario_seed=seed)
                    sim.set_start_and_goal((1.0, 1.0), (9.0, 9.0))
                    sim.plan_global_path(planner)
                    for _ in range(1200):
                        sim.step(0.05, "Adaptive_CTC", "ANFIS_APF", 0.5)
                        if sim.is_done:
                            break
                    self.assertTrue(sim.is_done)
                    self.assertFalse(sim.collision_occurred)


    def test_all_dashboard_configuration_combinations_smoke(self):
        # Every selectable combination must initialize and execute several steps.
        for robot, planner, local, controller in itertools.product(
            ["burger", "waffle", "pioneer"],
            ["AStar", "RRTStar", "Genetic"],
            ["APF", "ANFIS_APF", "DWA"],
            ["CTC", "Adaptive_CTC", "SMC"],
        ):
            with self.subTest(robot=robot, planner=planner, local=local, controller=controller):
                sim = SimulationEngine(robot)
                sim.setup_default_map()
                sim.set_start_and_goal((1.0, 1.0), (9.0, 9.0))
                path = sim.plan_global_path(planner)
                self.assertGreaterEqual(len(path), 2)
                for _ in range(5):
                    result = sim.step(0.05, controller, local, 0.5)
                    self.assertIn("pose", result)

    def test_recommended_pipeline_reaches_goal_for_all_robot_presets(self):
        for robot in ["burger", "waffle", "pioneer"]:
          for seed in (0, 1, 2):  # fixed scenarios -> reproducible, non-flaky
            with self.subTest(robot=robot, seed=seed):
                sim = SimulationEngine(robot)
                sim.setup_default_map(scenario_seed=seed)
                sim.set_start_and_goal((1.0, 1.0), (9.0, 9.0))
                sim.plan_global_path("AStar")
                for _ in range(1000):
                    sim.step(0.05, "Adaptive_CTC", "ANFIS_APF", 0.5)
                    if sim.is_done:
                        break
                self.assertTrue(sim.is_done)
                self.assertFalse(sim.collision_occurred)
                self.assertLess(np.linalg.norm(sim.pose[:2] - sim.goal), 0.3 + 1e-9)


class TestCustomStartGoal(unittest.TestCase):
    def test_user_selected_points_are_used_by_every_planner(self):
        start, goal = (1.0, 9.0), (9.0, 1.0)
        for planner in ["AStar", "RRTStar", "Genetic"]:
            with self.subTest(planner=planner):
                sim = SimulationEngine("burger")
                sim.setup_default_map(scenario_seed=3, start=start, goal=goal)
                self.assertIsNone(sim.validate_point(start, "Start"))
                self.assertIsNone(sim.validate_point(goal, "Goal"))
                sim.set_start_and_goal(start, goal)
                path = sim.plan_global_path(planner)
                self.assertTrue(sim.path_is_safe)
                self.assertAlmostEqual(path[0][0], 1.0)
                self.assertAlmostEqual(path[0][1], 9.0)
                self.assertAlmostEqual(path[-1][0], 9.0)
                self.assertAlmostEqual(path[-1][1], 1.0)
                for _ in range(1500):
                    sim.step(0.05, "Adaptive_CTC", "ANFIS_APF", 0.5)
                    if sim.is_done:
                        break
                self.assertTrue(sim.is_done)
                self.assertFalse(sim.collision_occurred)

    def test_invalid_points_are_rejected_by_api(self):
        from web.app import app
        client = app.test_client()
        bad = [([4.0, 5.0], [9.0, 9.0]),   # inside the pillar
               ([0.1, 0.1], [9.0, 9.0]),   # on the border wall
               ([5.0, 5.0], [5.3, 5.2])]   # start and goal too close
        for s_pt, g_pt in bad:
            r = client.post("/api/init", json={"start": s_pt, "goal": g_pt, "scenario_seed": 1})
            self.assertEqual(r.status_code, 400)
            self.assertIn("error", r.get_json())
        ok0 = client.post("/api/init", json={"robot": "pioneer", "scenario_seed": 1}).get_json()
        self.assertEqual(ok0["robot_geometry"]["name"], "Pioneer 3-DX")   # used by the 3D view
        ok = client.post("/api/init", json={"start": [1.0, 9.0], "goal": [8.0, 8.0], "scenario_seed": 1})
        self.assertEqual(ok.status_code, 200)


class TestPythonViewer(unittest.TestCase):
    def test_run_3d_renders_png(self):
        try:
            import matplotlib  # noqa: F401
        except ImportError:
            self.skipTest("matplotlib not installed")
        import subprocess, tempfile
        root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        with tempfile.TemporaryDirectory() as d:
            out = os.path.join(d, "f.png")
            r = subprocess.run([sys.executable, os.path.join(root, "run_3d.py"), "--seed", "2",
                                "--stride", "20", "--no-show", "--png", out],
                               capture_output=True, text=True, timeout=280,
                               env={**os.environ, "MPLBACKEND": "Agg"})
            self.assertEqual(r.returncode, 0, r.stderr[-500:])
            self.assertTrue(os.path.getsize(out) > 5000)
