"""
System Unit Tests
Tests kinematic equations, Lagrangian dynamics, controllers, planners, and simulation engine.
"""

import os
import sys

# Allow running this file directly (e.g. VS Code "Run Python File"): put the
# project root on the import path so `simulation`, `config`, etc. are found.
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


import unittest
import numpy as np
from config.robot_configs import TURTLEBOT3_BURGER
from robot_model.kinematics import DifferentialDriveKinematics
from robot_model.dynamics import DifferentialDriveDynamics
from robot_model.symbolic_verifier import verify_symbolic_dynamics
from controllers.lyapunov_kinematic import LyapunovKinematicController
from controllers.computed_torque import ComputedTorqueController
from controllers.sliding_mode import SlidingModeController
from planners.global_planners import AStarPlanner, RRTStarPlanner
from planners.local_planners import ArtificialPotentialField
from simulation.simulator import SimulationEngine

class TestAMRSystem(unittest.TestCase):
    def setUp(self):
        self.config = TURTLEBOT3_BURGER
        self.kinematics = DifferentialDriveKinematics(self.config)
        self.dynamics = DifferentialDriveDynamics(self.config)

    def test_kinematics_conversion(self):
        v, omega = 0.2, 0.5
        w_l, w_r = self.kinematics.robot_to_wheel_velocities(v, omega)
        v_calc, omega_calc = self.kinematics.wheel_to_robot_velocities(w_l, w_r)
        self.assertAlmostEqual(v, v_calc, places=5)
        self.assertAlmostEqual(omega, omega_calc, places=5)

    def test_symbolic_dynamics_proof(self):
        res = verify_symbolic_dynamics()
        self.assertTrue(res["overall_symbolic_proof"])

    def test_newton_euler_numerical_match(self):
        v_vec = np.array([0.1, 0.2])
        tau = np.array([0.05, 0.08])
        res = self.dynamics.newton_euler_cross_check(v_vec, tau)
        self.assertTrue(res["match"])

    def test_lyapunov_controller(self):
        ctrl = LyapunovKinematicController()
        pose = np.array([0.0, 0.0, 0.0])
        target_pose = np.array([1.0, 0.0, 0.0])
        v_c, omega_c, e_vec = ctrl.compute_control(pose, target_pose, 0.2, 0.0)
        self.assertGreaterThan = self.assertGreater(v_c, 0.0)

    def test_computed_torque_controller(self):
        ctc = ComputedTorqueController(self.dynamics)
        current_v = np.array([0.1, 0.0])
        target_v = np.array([0.2, 0.1])
        tau = ctc.compute_control(current_v, target_v, dt=0.05)
        self.assertEqual(len(tau), 2)
        self.assertTrue(np.all(np.abs(tau) <= self.config.max_torque))

    def test_astar_planner(self):
        grid = np.zeros((20, 20), dtype=int)
        grid[5:15, 10] = 1 # Wall obstacle
        planner = AStarPlanner(grid, resolution=0.1, robot_radius=0.1)
        path = planner.plan((0.2, 0.2), (1.8, 1.8))
        self.assertGreater(len(path), 1)

    def test_simulation_step(self):
        sim = SimulationEngine()
        sim.setup_default_map()
        sim.set_start_and_goal((1.0, 1.0), (9.0, 9.0))
        info = sim.step(dt=0.05)
        self.assertIn("pose", info)
        self.assertIn("torques", info)

if __name__ == "__main__":
    unittest.main()
