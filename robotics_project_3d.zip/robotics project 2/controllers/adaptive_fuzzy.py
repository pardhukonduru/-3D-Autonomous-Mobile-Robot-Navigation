"""
Adaptive Layer: Fuzzy-PID Gain Adaptor / ANFIS Gain Tuner
Adjusts dynamic tracking gains online based on current tracking error and error derivative.
Resilient against mass parameter uncertainty (e.g. payload changes) and ground friction changes.
"""

import numpy as np

class AdaptiveFuzzyTuner:
    def __init__(self):
        pass

    @staticmethod
    def triangular_mf(x: float, a: float, b: float, c: float) -> float:
        """Triangular membership function."""
        if x <= a or x >= c:
            return 0.0
        elif a < x <= b:
            return (x - a) / (b - a) if (b - a) > 0 else 1.0
        else:
            return (c - x) / (c - b) if (c - b) > 0 else 1.0

    @staticmethod
    def trapezoidal_mf(x: float, a: float, b: float, c: float, d: float) -> float:
        """Trapezoidal membership function."""
        if x <= a or x >= d:
            return 0.0
        elif a < x <= b:
            return (x - a) / (b - a) if (b - a) > 0 else 1.0
        elif b < x <= c:
            return 1.0
        else:
            return (d - x) / (d - c) if (d - c) > 0 else 1.0

    def compute_adaptation_factor(self, error: float, error_dot: float) -> float:
        """
        Inputs:
          error: |v_target - v_current|
          error_dot: |d_error / dt|
        Returns: adaptation multiplier alpha in range [1.0, 2.5]
        Rules:
          IF Error is Large OR ErrorDot is Large THEN Adaptation is High
          IF Error is Medium AND ErrorDot is Medium THEN Adaptation is Medium
          IF Error is Small AND ErrorDot is Small THEN Adaptation is Baseline (1.0)
        """
        abs_e = abs(error)
        abs_edot = abs(error_dot)

        # Fuzzify Error (Small, Medium, Large)
        e_small = self.trapezoidal_mf(abs_e, 0.0, 0.0, 0.05, 0.15)
        e_med = self.triangular_mf(abs_e, 0.10, 0.25, 0.40)
        e_large = self.trapezoidal_mf(abs_e, 0.30, 0.50, 10.0, 10.0)

        # Fuzzify Error Dot
        ed_small = self.trapezoidal_mf(abs_edot, 0.0, 0.0, 0.10, 0.30)
        ed_med = self.triangular_mf(abs_edot, 0.20, 0.50, 0.80)
        ed_large = self.trapezoidal_mf(abs_edot, 0.60, 1.0, 10.0, 10.0)

        # Rule evaluation (Mamdani max-min inference)
        w_high = max(e_large, ed_large)
        w_med = max(min(e_med, ed_med), min(e_small, ed_large), min(e_large, ed_small))
        w_low = min(e_small, ed_small)

        total_weight = w_high + w_med + w_low + 1e-6

        # Defuzzification (Center of Gravity)
        # Singleton output values: Low -> 1.0, Medium -> 1.5, High -> 2.2
        alpha = (w_low * 1.0 + w_med * 1.5 + w_high * 2.2) / total_weight
        return float(alpha)
