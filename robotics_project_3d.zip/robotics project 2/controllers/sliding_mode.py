"""
Dynamic Layer: Sliding Mode Controller (SMC)
Features a continuous boundary layer (tanh/sat) to eliminate chattering while maintaining
finite-time convergence and robust parameter uncertainty rejection.
"""

import numpy as np
from robot_model.dynamics import DifferentialDriveDynamics

class SlidingModeController:
    def __init__(
        self,
        dynamics: DifferentialDriveDynamics,
        lambda_s: float = 2.5,
        eta: float = 1.0,
        K_s: float = 1.5,
        boundary_phi: float = 0.05
    ):
        self.dynamics = dynamics
        self.lambda_s = lambda_s
        self.eta = eta
        self.K_s = K_s
        self.phi = boundary_phi

        self.integral_error = np.zeros(2)

    def reset(self):
        self.integral_error = np.zeros(2)

    def compute_control(
        self,
        current_v: np.ndarray,
        target_v: np.ndarray,
        dt: float,
        target_v_dot: np.ndarray = None
    ) -> np.ndarray:
        """
        Computes robust wheel torques using Sliding Mode control.
        current_v: [v, omega]
        target_v: [v_c, omega_c]
        """
        if target_v_dot is None:
            target_v_dot = np.zeros(2)

        error = target_v - current_v
        self.integral_error += error * dt
        self.integral_error = np.clip(self.integral_error, -2.0, 2.0)

        # Sliding surface S = e_v + lambda * int(e_v) dt
        S = error + self.lambda_s * self.integral_error

        # Boundary layer saturation function to eliminate high-frequency chattering
        # sat(S/phi) ~ np.tanh(S / phi)
        sat_S = np.tanh(S / self.phi)

        # Reaching control term: v_dot_ref = v_dot_target + lambda*e + eta*sat(S/phi) + K_s*S
        v_dot_ref = target_v_dot + self.lambda_s * error + self.eta * sat_S + self.K_s * S

        # Inverse dynamics feedforward torque
        tau = self.dynamics.inverse_dynamics(current_v, v_dot_ref)
        return tau
