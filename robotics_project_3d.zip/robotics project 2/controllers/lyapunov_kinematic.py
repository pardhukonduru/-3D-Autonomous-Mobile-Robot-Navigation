"""
Kinematic Layer: Lyapunov-based Pose Tracking Controller (Kanayama Controller)
Transforms pose tracking error [e_x, e_y, e_theta] into velocity commands (v_c, omega_c).
"""

import numpy as np
from robot_model.kinematics import DifferentialDriveKinematics

class LyapunovKinematicController:
    def __init__(self, K_x: float = 1.5, K_y: float = 4.0, K_theta: float = 2.0):
        self.K_x = K_x
        self.K_y = K_y
        self.K_theta = K_theta

    def compute_control(
        self,
        current_pose: np.ndarray,
        desired_pose: np.ndarray,
        desired_v: float,
        desired_omega: float
    ) -> tuple[float, float, np.ndarray]:
        """
        Computes velocity targets (v_c, omega_c) using Kanayama Lyapunov controller.
        current_pose: [x, y, theta]
        desired_pose: [x_d, y_d, theta_d]
        """
        x, y, theta = current_pose[0], current_pose[1], current_pose[2]
        x_d, y_d, theta_d = desired_pose[0], desired_pose[1], desired_pose[2]

        # Calculate error vector in world frame
        dx = x_d - x
        dy = y_d - y
        dtheta = DifferentialDriveKinematics.normalize_angle(theta_d - theta)

        # Transform error to robot local frame
        cos_th = np.cos(theta)
        sin_th = np.sin(theta)

        e_x = cos_th * dx + sin_th * dy
        e_y = -sin_th * dx + cos_th * dy
        e_theta = dtheta

        # Kanayama control law:
        # v_c = v_d * cos(e_theta) + K_x * e_x
        # omega_c = omega_d + K_y * v_d * sinc(e_theta) * e_y + K_theta * sin(e_theta)
        # where sinc(x) = sin(x)/x (or 1 when x -> 0)

        sinc_e = np.sin(e_theta) / e_theta if abs(e_theta) > 1e-5 else 1.0

        v_c = desired_v * np.cos(e_theta) + self.K_x * e_x
        omega_c = desired_omega + self.K_y * desired_v * sinc_e * e_y + self.K_theta * np.sin(e_theta)

        error_vector = np.array([e_x, e_y, e_theta])
        return v_c, omega_c, error_vector
