"""
Dynamic Layer: Computed-Torque Controller (CTC)
Transforms target velocities (v_c, omega_c) into wheel torques tau = [tau_l, tau_r]^T
using model-based inverse dynamics feedforward + PID feedback.
"""

import numpy as np
from robot_model.dynamics import DifferentialDriveDynamics
from config.robot_configs import RobotConfig, TURTLEBOT3_BURGER

class ComputedTorqueController:
    def __init__(
        self,
        dynamics: DifferentialDriveDynamics,
        K_p: float = 15.0,
        K_i: float = 1.0,
        K_d: float = 0.05,
        max_linear_accel: float = 1.5,
        max_angular_accel: float = 3.0
    ):
        self.dynamics = dynamics
        self.K_p = K_p
        self.K_i = K_i
        self.K_d = K_d
        self.max_linear_accel = max_linear_accel
        self.max_angular_accel = max_angular_accel

        self.integral_error = np.zeros(2)
        self.prev_error = np.zeros(2)

    def reset(self):
        self.integral_error = np.zeros(2)
        self.prev_error = np.zeros(2)

    def compute_control(
        self,
        current_v: np.ndarray,
        target_v: np.ndarray,
        dt: float,
        target_v_dot: np.ndarray = None
    ) -> np.ndarray:
        """
        current_v: [v, omega]
        target_v: [v_c, omega_c]
        target_v_dot: [dv_c/dt, domega_c/dt]
        Returns: wheel torques tau = [tau_l, tau_r]^T
        """
        if target_v_dot is None:
            target_v_dot = np.zeros(2)

        # Velocity error
        error = target_v - current_v
        self.integral_error += error * dt
        # Anti-windup
        self.integral_error = np.clip(self.integral_error, -5.0, 5.0)

        d_error = (error - self.prev_error) / dt if dt > 0 else np.zeros(2)
        self.prev_error = error.copy()

        # Desired acceleration v_dot_ref = v_dot_target + K_p*e + K_i*int(e) + K_d*de/dt
        v_dot_ref = target_v_dot + self.K_p * error + self.K_i * self.integral_error + self.K_d * d_error

        # Limit requested acceleration to avoid torque saturation and
        # high-frequency angular reversals in the physical model.
        v_dot_ref[0] = float(np.clip(
            v_dot_ref[0], -self.max_linear_accel, self.max_linear_accel
        ))
        v_dot_ref[1] = float(np.clip(
            v_dot_ref[1], -self.max_angular_accel, self.max_angular_accel
        ))

        # Inverse dynamics feedforward
        tau = self.dynamics.inverse_dynamics(current_v, v_dot_ref)
        return tau
